// [container storage bridge] Prefer mini-tool Storage JS API (client 9.46+),
// fall back to browser localStorage on lower versions or outside the container.
(function () {
  var STORAGE_MIN_CLIENT_VERSION = 9460; // client 9.46.0
  var PREFIX = "hx4725_";

  function readBuildVersion(launchOptions) {
    var env = launchOptions && launchOptions.miniToolEnv;
    return Number(env && env.buildVersion) || 0;
  }

  async function getBuildVersion() {
    var xhs = window.xhs;
    var syncVersion = readBuildVersion(xhs && xhs.launchOptions);
    if (syncVersion) return syncVersion;
    var miniTool = xhs && xhs.miniTool;
    if (!miniTool || typeof miniTool.getLaunchOptions !== "function") return 0;
    try {
      var options = await miniTool.getLaunchOptions();
      return readBuildVersion(options);
    } catch (error) {
      return 0;
    }
  }

  async function resolveStorage() {
    var miniTool = window.xhs && window.xhs.miniTool;
    if (!miniTool) return null;
    if (typeof miniTool.setStorage !== "function") return null;
    if (typeof miniTool.getStorage !== "function") return null;
    var buildVersion = await getBuildVersion();
    if (Math.floor(buildVersion / 1000) < STORAGE_MIN_CLIENT_VERSION) return null;
    return miniTool;
  }

  window.GameSDK = {
    init: async function () {
      var miniTool = await resolveStorage();
      return {
        context: {
          gameId: 4725,
          platform: miniTool ? "minitool" : "local-desktop"
        },
        storage: {
          async get(params) {
            var key = PREFIX + params.key;
            if (miniTool) {
              try {
                var result = await miniTool.getStorage({ key: key });
                var raw = result && result.data;
                return { value: raw ? JSON.parse(raw) : null };
              } catch (error) {
                /* fall through to browser storage */
              }
            }
            try {
              var local = localStorage.getItem(key);
              return { value: local ? JSON.parse(local) : null };
            } catch (error) {
              return { value: null };
            }
          },
          async set(params) {
            var key = PREFIX + params.key;
            var data = JSON.stringify(params.value);
            if (typeof data !== "string") return {};
            if (miniTool) {
              try {
                await miniTool.setStorage({ key: key, data: data });
                return {};
              } catch (error) {
                /* fall through to browser storage */
              }
            }
            try {
              localStorage.setItem(key, data);
            } catch (error) {
              /* container may drop browser storage; ignore */
            }
            return {};
          }
        }
      };
    }
  };
})();
