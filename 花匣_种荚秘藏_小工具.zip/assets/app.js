(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __objRest = (source, exclude) => {
    var target = {};
    for (var prop in source)
      if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
        target[prop] = source[prop];
    if (source != null && __getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(source)) {
        if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
          target[prop] = source[prop];
      }
    return target;
  };
  var ART = {
    // 主视觉 / 场景
    hero: `./assets/img/00_hero.webp`,
    scenes: {
      house: `./assets/img/01_house.webp`,
      workshop: `./assets/img/02_workshop.webp`,
      market: `./assets/img/03_market.webp`
    },
    // 种荚（基础 4 档 + 扩充 6 档，其中 golden / timeless 为隐藏档）
    pods: {
      common: `./assets/img/04_common.webp`,
      old: `./assets/img/05_old.webp`,
      mystic: `./assets/img/06_mystic.webp`,
      broken: `./assets/img/07_broken.webp`,
      moss: `./assets/img/08_moss.webp`,
      moonlit: `./assets/img/09_moonlit.webp`,
      starlight: `./assets/img/10_starlight.webp`,
      mistpeak: `./assets/img/11_mistpeak.webp`,
      golden: `./assets/img/12_golden.webp`,
      timeless: `./assets/img/13_timeless.webp`
    },
    // 花（普通 10 / 稀有 8 / 变异 6）
    flowers: {
      yumeiren: `./assets/img/14_yumeiren.webp`,
      fuseyueji: `./assets/img/15_fuseyueji.webp`,
      yeguanghua: `./assets/img/16_yeguanghua.webp`,
      xiaochuju: `./assets/img/17_xiaochuju.webp`,
      wuwangwo: `./assets/img/18_wuwangwo.webp`,
      chongbanshaoyao: `./assets/img/19_chongbanshaoyao.webp`,
      xingmang: `./assets/img/20_xingmang.webp`,
      linglan: `./assets/img/21_linglan.webp`,
      mantianxing: `./assets/img/22_mantianxing.webp`,
      fengxinzi: `./assets/img/23_fengxinzi.webp`,
      lanxiuqiu: `./assets/img/24_lanxiuqiu.webp`,
      fuguyujinxiang: `./assets/img/25_fuguyujinxiang.webp`,
      shanchahua: `./assets/img/26_shanchahua.webp`,
      jiguangyuanwei: `./assets/img/27_jiguangyuanwei.webp`,
      yingguanglian: `./assets/img/28_yingguanglian.webp`,
      // 《种荚秘藏》扩充
      yangganju: `./assets/img/29_yangganju.webp`,
      xiangwandou: `./assets/img/30_xiangwandou.webp`,
      shicheju: `./assets/img/31_shicheju.webp`,
      ziluolan: `./assets/img/32_ziluolan.webp`,
      lvmudan: `./assets/img/33_lvmudan.webp`,
      zitenghua: `./assets/img/34_zitenghua.webp`,
      yangmudan: `./assets/img/35_yangmudan.webp`,
      liulihua: `./assets/img/36_liulihua.webp`,
      yinbaihe: `./assets/img/37_yinbaihe.webp`
    },
    // 手作成品（押花 24 + 滴胶 6 + 通用 2）
    crafts: {
      paint: `./assets/img/38_paint.webp`,
      resinCombo: `./assets/img/39_resinCombo.webp`,
      press_yumeiren: `./assets/img/40_press_yumeiren.webp`,
      press_wuwangwo: `./assets/img/41_press_wuwangwo.webp`,
      press_xiaochuju: `./assets/img/42_press_xiaochuju.webp`,
      press_fuseyueji: `./assets/img/43_press_fuseyueji.webp`,
      press_chongbanshaoyao: `./assets/img/44_press_chongbanshaoyao.webp`,
      press_linglan: `./assets/img/45_press_linglan.webp`,
      press_mantianxing: `./assets/img/46_press_mantianxing.webp`,
      press_fengxinzi: `./assets/img/47_press_fengxinzi.webp`,
      press_lanxiuqiu: `./assets/img/48_press_lanxiuqiu.webp`,
      press_fuguyujinxiang: `./assets/img/49_press_fuguyujinxiang.webp`,
      press_shanchahua: `./assets/img/50_press_shanchahua.webp`,
      press_yeguanghua: `./assets/img/51_press_yeguanghua.webp`,
      press_xingmang: `./assets/img/52_press_xingmang.webp`,
      press_jiguangyuanwei: `./assets/img/53_press_jiguangyuanwei.webp`,
      press_yingguanglian: `./assets/img/54_press_yingguanglian.webp`,
      resin_yeguanghua: `./assets/img/55_resin_yeguanghua.webp`,
      resin_xingmang: `./assets/img/56_resin_xingmang.webp`,
      resin_jiguangyuanwei: `./assets/img/57_resin_jiguangyuanwei.webp`,
      resin_yingguanglian: `./assets/img/58_resin_yingguanglian.webp`,
      // 《种荚秘藏》扩充
      press_yangganju: `./assets/img/59_press_yangganju.webp`,
      press_xiangwandou: `./assets/img/60_press_xiangwandou.webp`,
      press_shicheju: `./assets/img/61_press_shicheju.webp`,
      press_ziluolan: `./assets/img/62_press_ziluolan.webp`,
      press_lvmudan: `./assets/img/63_press_lvmudan.webp`,
      press_zitenghua: `./assets/img/64_press_zitenghua.webp`,
      press_yangmudan: `./assets/img/65_press_yangmudan.webp`,
      press_liulihua: `./assets/img/66_press_liulihua.webp`,
      press_yinbaihe: `./assets/img/67_press_yinbaihe.webp`,
      resin_liulihua: `./assets/img/68_resin_liulihua.webp`,
      resin_yinbaihe: `./assets/img/69_resin_yinbaihe.webp`
    },
    // 花匣（《花匣·种子》玩法）。多状态图以雪碧图整图下发，运行时按格确定性定位显示，
    // 不做物理切分（既避免重编码损失，也少 10 个请求）。切分契约见下方 rows/cols 与 manifest。
    box: {
      closed: `./assets/img/70_closed_sheet.webp`,
      // 完全闭合：全家族身份锚点，兼叙事弹窗配图
      states: { url: `./assets/img/71_url_sheet.webp`, rows: 2, cols: 2 }
      // 微开 / 半开 / 大开 / 过度张开
    },
    // 种子结果：完好 / 破损 / 损毁 / 完好·高亮（2×2，行优先）
    seeds: { url: `./assets/img/72_url_sheet.webp`, rows: 2, cols: 2 },
    // 道具图标：2 列 × 3 行，每格 512×341（3:2），行优先
    props: { url: `./assets/img/73_url_sheet.webp`, rows: 3, cols: 2 }
  };
  var START_COIN = 100;
  var RESIN_UNLOCK_EARN = 600;
  var AUCTION_EARN = 1e4;
  var REFUND_WINDOW_MS = 3e4;
  var REFRESH_COST = 3;
  var PRICE_SWING = 0.15;
  var GOLDEN_GUEST_ODD = 20;
  var TIMELESS_UNLOCK_OPENS = 50;
  var TIMELESS_DAILY_STOCK = 1;
  var PODS = [
    {
      id: "common",
      name: "普通种荚",
      price: 10,
      tag: "入门·草木香",
      peel: 3,
      grow: 5,
      prob: { normal: 0.9, rare: 0.09, variant: 0.01 },
      dead: 0,
      hint: "外壳干燥起皱，闻着有淡淡草木香"
    },
    {
      id: "old",
      name: "古旧种荚",
      price: 30,
      tag: "常见·陈年封存",
      peel: 4,
      grow: 7,
      prob: { normal: 0.35, rare: 0.57, variant: 0.08 },
      dead: 0,
      hint: "麻布层层包裹，一角泛黄"
    },
    {
      id: "mystic",
      name: "秘境种荚",
      price: 70,
      tag: "精品·山林秘境",
      peel: 5,
      grow: 9,
      prob: { normal: 0.05, rare: 0.7, variant: 0.25 },
      dead: 0,
      hint: "表面浮着星点微光，来自深山"
    },
    {
      id: "broken",
      name: "残损秘荚",
      price: 20,
      tag: "赌荚·外壳破损",
      peel: 4,
      grow: 6,
      prob: { normal: 0.25, rare: 0.5, variant: 0.25 },
      dead: 0.4,
      hint: "缝隙透出一丝芽绿，是福是祸"
    },
    // —— 《种荚秘藏》扩充 ——
    {
      id: "moss",
      name: "苔藓种荚",
      price: 12,
      tag: "入门·苔香松软",
      peel: 3,
      grow: 5,
      prob: { normal: 0.8, rare: 0.2, variant: 0 },
      dead: 0,
      hint: "裹着一层干苔藓，摸起来松软微凉"
    },
    {
      id: "moonlit",
      name: "月华秘荚",
      price: 40,
      tag: "精品·月下封存",
      peel: 5,
      grow: 8,
      prob: { normal: 0.45, rare: 0.5, variant: 0.05 },
      dead: 0,
      hint: "壳面有银蓝光泽，像在月光下放了一整夜"
    },
    {
      id: "starlight",
      name: "星辉灵荚",
      price: 60,
      tag: "稀有·星屑入壳",
      peel: 5,
      grow: 9,
      prob: { normal: 0.1, rare: 0.8, variant: 0.1 },
      dead: 0,
      hint: "摇一摇有细碎响动，是壳里的星屑在滚"
    },
    {
      id: "mistpeak",
      name: "山岚雾荚",
      price: 85,
      tag: "稀有·云雾山脊",
      peel: 6,
      grow: 10,
      prob: { normal: 0.02, rare: 0.63, variant: 0.35 },
      dead: 0,
      hint: "揭开时有凉气冒出，带着高山雾的味道"
    },
    {
      id: "golden",
      name: "黄金灵荚",
      price: 110,
      tag: "隐藏·鎏金必出",
      peel: 6,
      grow: 10,
      prob: { normal: 0, rare: 0.55, variant: 0.45 },
      dead: 0,
      hint: "整枚匣身鎏金，客人说它从不让人空手而归",
      hidden: "guest"
    },
    {
      id: "timeless",
      name: "时间古荚",
      price: 150,
      tag: "隐藏·年代沉眠",
      peel: 7,
      grow: 12,
      prob: { normal: 0, rare: 0.15, variant: 0.85 },
      dead: 0,
      hint: "壳面裂纹像年轮，据说沉睡了几十年",
      hidden: "milestone"
    }
  ];
  var QUALITY = {
    normal: { label: "普通", material: "花瓣", cls: "q-normal" },
    rare: { label: "稀有", material: "花瓣", cls: "q-rare" },
    variant: { label: "变异", material: "花蕊", cls: "q-variant" }
  };
  var MATERIAL_VALUE = { normal: 8, rare: 55, variant: 160 };
  var CONSUMABLES = {
    card: { name: "卡纸", price: 2, desc: "押花衬底，每张押花都要用" },
    frame: { name: "相框", price: 5, desc: "装裱装饰画用" },
    resin: { name: "滴胶", price: 8, desc: "封存变异花材" },
    ribbon: { name: "丝带", price: 4, desc: "滴胶成品的收边" }
  };
  var CONSUMABLE_COLOR = { card: "#C9B28A", frame: "#A98F6B", resin: "#9FB8D8", ribbon: "#E3A7B8" };
  var FLOWERS = [
    { id: "yumeiren", name: "虞美人", quality: "normal", sci: "花语「安慰」。传说它的红是虞姬洒落的泪染成的，风一吹，薄如绢的花瓣就轻轻颤。" },
    { id: "xiaochuju", name: "小雏菊", quality: "normal", sci: "花语「天真与藏在心底的爱」。晨露停在鹅黄花心上，像谁悄悄许下的愿望。" },
    { id: "wuwangwo", name: "勿忘我", quality: "normal", sci: "花语「请不要忘记我」。晒干了颜色也不褪，最适合压进书页，陪伴很多年。" },
    { id: "linglan", name: "铃兰", quality: "normal", sci: "花语「幸福归来」。一串小小的白铃铛垂在叶间，据说铃音响起的地方就有好运。" },
    { id: "mantianxing", name: "满天星", quality: "normal", sci: "花语「甘愿做配角的温柔」。细碎的白花开成一团云雾，把主角衬得更亮。" },
    { id: "fengxinzi", name: "风信子", quality: "normal", sci: "花语「重生的喜悦」。球茎里蓄着一整个春天，蓝紫色的穗子香气最沉。" },
    { id: "fuseyueji", name: "复色月季", quality: "rare", sci: "花语「变化的美丽」。同一朵花上有两种颜色，像清晨与黄昏同时开放。" },
    { id: "chongbanshaoyao", name: "重瓣芍药", quality: "rare", sci: "花语「富贵与惜别」。花瓣层层叠叠抱成一团，古人称它为「花相」。" },
    { id: "lanxiuqiu", name: "蓝绣球", quality: "rare", sci: "花语「善变与团圆」。土壤能让它在粉与蓝之间变换，雨后那一球蓝得最透。" },
    { id: "fuguyujinxiang", name: "复古郁金香", quality: "rare", sci: "花语「优雅的旧时光」。像从老画册里剪下来的一抹暮色，越看越安静。" },
    { id: "shanchahua", name: "山茶花", quality: "rare", sci: "花语「理想的爱」。寒冬里慢慢开花，然后整朵整朵地落，干脆又体面。" },
    { id: "yeguanghua", name: "夜光花", quality: "variant", sci: "变异档案：花瓣在暗处泛出萤萤微光，花娘说，那是月光在花里存了一夜。" },
    { id: "xingmang", name: "星芒渐变花", quality: "variant", sci: "变异档案：瓣尖有细碎星斑，珊瑚粉一路晕进淡紫，像握住了一小片星空。" },
    { id: "jiguangyuanwei", name: "极光鸢尾", quality: "variant", sci: "变异档案：花瓣上流动着极光般的色带，烤蓝与鎏金交替，随角度变换光泽。" },
    { id: "yingguanglian", name: "荧光莲", quality: "variant", sci: "变异档案：本该长在水里的花在荚中盛开，花心有一点荧光在缓缓呼吸。" },
    // —— 《种荚秘藏》扩充 ——
    { id: "yangganju", name: "洋甘菊", quality: "normal", sci: "花语「逆境中的温柔」。白瓣黄心小小一朵，泡水却有整整一夏的苹果香。" },
    { id: "xiangwandou", name: "香豌豆", quality: "normal", sci: "花语「离别与回忆」。花瓣薄得像皱起来的绸，风来时整串都在轻轻晃。" },
    { id: "shicheju", name: "矢车菊", quality: "normal", sci: "花语「遇见与幸福」。麦田里最蓝的那一支，据说割完麦它就开得更用力。" },
    { id: "ziluolan", name: "紫罗兰", quality: "normal", sci: "花语「长久的思念」。紫色一小串藏在叶下，闻到了才想起它还开着。" },
    { id: "lvmudan", name: "绿牡丹", quality: "rare", sci: "花语「淡雅与稀有」。层层花瓣竟是通透的绿，老花匠说十年才养得出一株。" },
    { id: "zitenghua", name: "紫藤花", quality: "rare", sci: "花语「沉迷的爱的执着」。一串串垂下来像紫色的雨，落在旧木架上会发出很轻的声。" },
    { id: "yangmudan", name: "洋牡丹", quality: "rare", sci: "花语「你来了真好」。几十层薄瓣旋成一个圆，晨光一照，像谁把奶油搅开了。" },
    { id: "liulihua", name: "幻彩琉璃花", quality: "variant", sci: "变异档案：花瓣有彩虹渐变的琉璃质感，转动时会听见极轻的脆响，像风铃。" },
    { id: "yinbaihe", name: "月华银百合", quality: "variant", sci: "变异档案：银白花瓣浮着月光般的荧光，夜里独自开，香气是凉的。" }
  ];
  var RESIN_FORM = {
    yeguanghua: "滴胶胸针",
    xingmang: "滴胶书签",
    jiguangyuanwei: "滴胶吊坠",
    yingguanglian: "滴胶胸针",
    liulihua: "滴胶吊坠",
    yinbaihe: "滴胶胸针"
  };
  var RESIN_SELL = {
    yeguanghua: 210,
    xingmang: 205,
    jiguangyuanwei: 215,
    yingguanglian: 210,
    liulihua: 210,
    yinbaihe: 210
  };
  var CRAFTS = [
    ...FLOWERS.filter((f) => f.quality !== "variant").map((f) => ({
      id: `press_${f.id}`,
      kind: "press",
      flowerId: f.id,
      name: `押花·${f.name}`,
      need: { flower: f.id, n: 1 },
      consum: { card: 1 },
      fee: f.quality === "normal" ? 3 : 6,
      sell: f.quality === "normal" ? 18 : 78,
      quality: f.quality,
      img: ART.crafts[`press_${f.id}`]
    })),
    {
      id: "paint",
      kind: "paint",
      flowerId: null,
      name: "押花装饰画",
      need: { anyNormal: 3 },
      consum: { card: 1, frame: 1 },
      fee: 11,
      sell: 60,
      quality: "normal",
      img: ART.crafts.paint
    },
    ...FLOWERS.filter((f) => f.quality === "variant").map((f) => ({
      id: `resin_${f.id}`,
      kind: "resin",
      flowerId: f.id,
      name: `${RESIN_FORM[f.id]}·${f.name}`,
      need: { flower: f.id, n: 1 },
      consum: { resin: 1, ribbon: 1 },
      fee: 15,
      sell: RESIN_SELL[f.id],
      quality: "variant",
      img: ART.crafts[`resin_${f.id}`],
      baseImg: ART.crafts[`press_${f.id}`]
      // 滴胶前先压出的押花底样
    }))
  ];
  var TIPS = [
    "外壳会骗人，有人开出稀世花，也有人只得到几片枯叶。",
    "今天先做什么？接着经营，把库存里的种荚剥开。",
    "残损秘荚便宜，可它脾气坏——四成会黑腐哦。",
    "压好的花趁新鲜卖，铜币转起来，花坊才活得旺。",
    "秘境种荚浮着星点微光，是山那边的客人捎来的。",
    "变异花别急着变卖，做成滴胶能翻好几倍价钱。",
    "苔藓种荚便宜又老实，八成开出普通花，练手正合适。",
    "山岚雾荚凉气重，三成五的变异率，是赌一把的好选择。",
    "黄金灵荚只在少数日子驾到，看见了就别犹豫，它不让人空手。",
    "时间古荚攒够 50 枚才苏醒，一天只上 1 枚，先到先得。"
  ];
  function dayKey(d = /* @__PURE__ */ new Date()) {
    const p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  }
  function hashStr(s) {
    let h2 = 0;
    for (const c of s) h2 = h2 * 31 + c.codePointAt(0) >>> 0;
    return h2;
  }
  function flowerOfDay(key = dayKey()) {
    return FLOWERS[hashStr(key) % FLOWERS.length];
  }
  function flowerOfTomorrow(key = dayKey()) {
    const d = /* @__PURE__ */ new Date(`${key}T12:00:00`);
    d.setDate(d.getDate() + 1);
    return flowerOfDay(dayKey(d));
  }
  function goldenGuestToday(key = dayKey()) {
    return hashStr(`${key}:golden`) % GOLDEN_GUEST_ODD === 0;
  }
  var BOX_PRICE = 60;
  var BOX_DAILY_FREE = 1;
  var BOX_GIFT_BASE = 1;
  var ANGLE_TOO_TIGHT = 18;
  var ANGLE_BANDS = [
    { max: 30, label: "微开", cell: 0 },
    { max: 62, label: "半开", cell: 1 },
    { max: 82, label: "大开", cell: 2 },
    { max: 100, label: "过度张开", cell: 3 }
  ];
  var ANGLE_DANGER = 82;
  var TORCH_PAD = 4;
  var INTACT_LO = ANGLE_BANDS[0].max;
  var INTACT_HI = ANGLE_BANDS[1].max;
  var BOX_PROPS = {
    torch: {
      name: "微光手电筒",
      price: 30,
      sprite: 0,
      stage: "pre",
      desc: "照亮匣内布局，把「半开」这段完好区间向两侧各放宽 4 度，更容易停稳——但开过头照样会伤到种子。",
      effect: "完好区向两侧各 +4°"
    },
    lens: {
      name: "观星镜片",
      price: 34,
      sprite: 1,
      stage: "pre",
      desc: "标出安全开合区间，肉眼可见参考范围，可与手电筒叠加。",
      effect: "显示安全区间标线"
    },
    cloth: {
      name: "柔绒衬布",
      price: 26,
      sprite: 2,
      stage: "pre",
      desc: "缓冲匣内锐边，降低种子直接损毁概率，失误大多产出破损种子。",
      effect: "损毁降级为破损"
    },
    dew: {
      name: "轻息香露",
      price: 28,
      sprite: 3,
      stage: "pre",
      desc: "浸润匣瓣，滑动手感顺滑，减少大幅度误触。",
      effect: "滑动阻尼平滑，抑制过冲"
    },
    paste: {
      name: "修复玉膏",
      price: 45,
      sprite: 4,
      stage: "post",
      desc: "开完匣后，可将破损种子修复为完好种子；彻底损毁的种子不可修复。",
      effect: "破损 → 完好（事后使用）"
    }
  };
  var PRE_PROPS = ["torch", "lens", "cloth", "dew"];
  var SEED_EXCHANGES = [
    { id: "coin_intact", need: { intact: 1 }, gain: { coin: 50 }, name: "换花铜币", note: "客人愿为饱满的种子出高价" },
    { id: "pack_rare", need: { intact: 2 }, gain: { consumables: { resin: 1, ribbon: 1 } }, name: "稀有耗材包", note: "滴胶 + 丝带 各 1" },
    { id: "quota_golden", need: { intact: 5 }, gain: { goldenQuota: 1 }, name: "稀荚配额", note: "今日花市必定上架黄金灵荚" },
    { id: "coin_broken", need: { broken: 1 }, gain: { coin: 10 }, name: "碎种变卖", note: "破损种子也能换点零钱" },
    { id: "pack_card", need: { broken: 2 }, gain: { consumables: { card: 2 } }, name: "卡纸补给", note: "卡纸 ×2" },
    { id: "pack_frame", need: { broken: 3 }, gain: { consumables: { frame: 1 } }, name: "相框补给", note: "相框 ×1" }
  ];
  var BOX_DECOR = {
    vase_gold: { name: "鎏金细颈花器", need: { intact: 3 }, note: "匣心取出的完好种子换来的鎏金器物" },
    lamp_night: { name: "温室夜灯", need: { intact: 4 }, note: "入夜后花房最温柔的一盏，客人愿意为它多留一会儿" },
    shelf_old: { name: "旧木花架", need: { intact: 2, broken: 3 }, note: "带虫眼的老木架，摆什么都有年代感" }
  };
  var DECOR_GIFT_BONUS = 1;
  var DECOR_GIFT_CAP = 3;
  var BOX_MILESTONES = [
    { at: 10, props: { torch: 1, cloth: 1 }, note: "开匣满 10 只：花娘送来手电与绒布" },
    { at: 25, props: { lens: 1, dew: 1 }, note: "开匣满 25 只：老客人捎来镜片与香露" },
    { at: 50, props: { paste: 2 }, note: "开匣满 50 只：匠人回赠修复玉膏 ×2" }
  ];
  var SEED_RESULTS = {
    intact: { title: "完好种子", line: "种子从匣心滑出来，壳面一丝划痕都没有。", tone: "gold" },
    broken: { title: "破损种子", line: "匣瓣的棱片刮伤了种壳——好在还能用。", tone: "warn" },
    ruined: { title: "种子损毁", line: "开得太猛，种子在匣瓣挤压下裂成了碎壳。这一只没有收成。", tone: "bad" },
    tight: { title: "取不出来", line: "匣瓣只松开一条缝，种子还卡在匣心里。再开大一点。", tone: "info" }
  };
  var BOX_FOOT_NOTE = "开合角度决定结果：停在「半开」取出完好种子，「大开」只会刮出破损种子，「过度张开」会直接损毁，开得太小则取不出来。各类道具仅提供辅助。";
  var BOX_STORY = "花匣的瓣壳柔软却内里带着薄锐的棱片，珍贵的种子沉睡在匣心。你可以滑动控制花匣张开的幅度。开得过大，匣瓣向内挤压，很容易刮伤匣内的种子；开得太小，又无法取出种子。若持有手电筒，微光可以穿透匣壁，看清种子在内部的摆放位置；观星镜片会标记安全开合区间，更容易找准安全的开合区间。操作得当收获完好种子；稍有不慎会得到破损种子；角度失控，种子则会直接损毁。";
  function initialState() {
    return {
      screen: "house",
      // house | market | workshop | album | flow | casket
      ui: { marketTab: "shop", workshopTab: "press", casketTab: "open" },
      coin: START_COIN,
      totalEarned: 0,
      // 累计赚到（解锁线用）
      pods: [],
      // [{uid, type, peeled, boughtAt, boughtPrice}]
      petals: {},
      // {flowerId: 数量}
      consumables: { card: 2, frame: 1, resin: 1, ribbon: 1 },
      // 开局送的少量耗材
      crafts: {},
      // {craftId: 数量}
      illustrated: {},
      // {flowerId: true}
      shelf: [],
      // 花房陈列 [flowerId]
      stats: { opened: 0, todayCount: 0, today: "", refreshUsed: false },
      supply: { day: "", prices: {}, sold: {} },
      // 当日货源浮动价 + 隐藏档当日用量
      pending: null,
      // {flowerId, quality} 绽放结果待选择（用于断线恢复）
      tutorialDone: false,
      // —— 《花匣·种子》——
      seeds: { intact: 0, broken: 0 },
      // 花匣产出
      boxProps: { torch: 0, lens: 0, cloth: 0, dew: 0, paste: 0 },
      // 辅助道具库存
      boxStats: { opened: 0, intact: 0, broken: 0, ruined: 0, milestones: {} },
      boxDecor: {},
      // 限定陈设 {decorId: true}
      boxDaily: { day: "", freeUsed: 0, giftTaken: false, goldenQuota: false },
      // —— \u82B1\u5E02\u5927\u62CD ——
      auction: { day: "", consigned: 0, lot: null, bids: [], rerolls: 0 }
      // \u5F53\u65E5\u5DF2\u59D4\u6258\u6570 / \u5F53\u524D\u62CD\u54C1 {kind,id,name,quality,base} / \u5BA2\u4EBA\u51FA\u4EF7
    };
  }
  var state = initialState();
  var subs = /* @__PURE__ */ new Set();
  var OBJ_FIELDS = ["petals", "consumables", "crafts", "illustrated", "boxDecor"];
  var DEEP_FIELDS = ["seeds", "boxProps", "boxStats", "boxDaily"];
  var ARR_FIELDS = ["pods", "shelf"];
  var SCREENS = ["house", "market", "workshop", "album", "flow", "casket"];
  var isPlainObj = (v) => !!v && typeof v === "object" && !Array.isArray(v);
  function normalize(s) {
    const base = initialState();
    const out = isPlainObj(s) ? __spreadValues(__spreadValues({}, base), s) : __spreadValues({}, base);
    for (const k of OBJ_FIELDS) if (!isPlainObj(out[k])) out[k] = __spreadValues({}, base[k]);
    for (const k of DEEP_FIELDS) out[k] = __spreadValues(__spreadValues({}, base[k]), isPlainObj(out[k]) ? out[k] : {});
    for (const k of ARR_FIELDS) if (!Array.isArray(out[k])) out[k] = [];
    out.stats = __spreadValues(__spreadValues({}, base.stats), isPlainObj(out.stats) ? out.stats : {});
    out.supply = __spreadValues(__spreadValues({}, base.supply), isPlainObj(out.supply) ? out.supply : {});
    if (!isPlainObj(out.supply.prices)) out.supply.prices = {};
    if (!isPlainObj(out.supply.sold)) out.supply.sold = {};
    if (!isPlainObj(out.boxStats.milestones)) out.boxStats.milestones = {};
    out.auction = __spreadValues(__spreadValues({}, base.auction), isPlainObj(out.auction) ? out.auction : {});
    if (!Array.isArray(out.auction.bids)) out.auction.bids = [];
    if (!isPlainObj(out.auction.lot)) out.auction.lot = null;
    out.ui = __spreadValues(__spreadValues({}, base.ui), isPlainObj(out.ui) ? out.ui : {});
    if (typeof out.coin !== "number" || !Number.isFinite(out.coin)) out.coin = base.coin;
    if (typeof out.totalEarned !== "number" || !Number.isFinite(out.totalEarned)) out.totalEarned = 0;
    if (!SCREENS.includes(out.screen)) out.screen = "house";
    return out;
  }
  function getState() {
    return state;
  }
  function setState(patch) {
    const next = typeof patch === "function" ? __spreadValues(__spreadValues({}, state), patch(state)) : __spreadValues(__spreadValues({}, state), patch);
    state = normalize(next);
    subs.forEach((fn) => fn(state));
  }
  function subscribe(fn) {
    subs.add(fn);
    return () => subs.delete(fn);
  }
  function replaceAll(next) {
    state = normalize(next);
    subs.forEach((fn) => fn(state));
  }
  var SAVE_KEY = "save:main";
  var SCHEMA_VERSION = 2;
  var memory = null;
  var POD_IDS = new Set(PODS.map((p) => p.id));
  var FLOWER_IDS = new Set(FLOWERS.map((f) => f.id));
  var CRAFT_IDS = new Set(CRAFTS.map((c) => c.id));
  var CONSUMABLE_IDS = Object.keys(CONSUMABLES);
  var SEED_KEYS = /* @__PURE__ */ new Set(["intact", "broken"]);
  var BOX_PROP_IDS = new Set(Object.keys(BOX_PROPS));
  var DECOR_IDS = new Set(Object.keys(BOX_DECOR));
  var isObj = (v) => !!v && typeof v === "object" && !Array.isArray(v);
  var numOf = (v, d) => typeof v === "number" && Number.isFinite(v) ? v : d;
  var intOf = (v, d) => Math.floor(numOf(v, d));
  function countsOf(raw, validIds) {
    const out = {};
    if (!isObj(raw)) return out;
    for (const [k, v] of Object.entries(raw)) {
      if (!validIds.has(k)) continue;
      const n = intOf(v, 0);
      if (n > 0) out[k] = n;
    }
    return out;
  }
  function flagsOf(raw, validIds) {
    const out = {};
    if (!isObj(raw)) return out;
    for (const [k, v] of Object.entries(raw)) {
      if (validIds.has(k) && v) out[k] = true;
    }
    return out;
  }
  function plainOf(s) {
    const _a = s, { screen, ui } = _a, rest = __objRest(_a, ["screen", "ui"]);
    void screen;
    void ui;
    return rest;
  }
  async function load(sdk) {
    try {
      if (!sdk) return memory;
      const { value } = await sdk.storage.get({ key: SAVE_KEY });
      return value != null ? value : null;
    } catch (e) {
      console.warn("[save] 读档失败，使用初始进度", e);
      return null;
    }
  }
  function mergeSave(raw) {
    const base = initialState();
    if (!isObj(raw)) return base;
    return __spreadProps(__spreadValues({}, base), {
      coin: Math.max(0, intOf(raw.coin, base.coin)),
      totalEarned: Math.max(0, intOf(raw.totalEarned, 0)),
      pods: (Array.isArray(raw.pods) ? raw.pods : []).filter(isObj).map((p) => ({
        uid: typeof p.uid === "string" && p.uid ? p.uid : "",
        type: p.type,
        peeled: p.peeled === true,
        damaged: p.damaged === true,
        boughtAt: numOf(p.boughtAt, 0),
        boughtPrice: Math.max(1, intOf(p.boughtPrice, 1))
      })).filter((p) => p.uid && POD_IDS.has(p.type)),
      petals: countsOf(raw.petals, FLOWER_IDS),
      consumables: (() => {
        if (!isObj(raw.consumables)) return __spreadValues({}, base.consumables);
        const out = {};
        for (const id of CONSUMABLE_IDS) out[id] = Math.max(0, intOf(raw.consumables[id], 0));
        return out;
      })(),
      crafts: countsOf(raw.crafts, CRAFT_IDS),
      illustrated: flagsOf(raw.illustrated, FLOWER_IDS),
      shelf: (Array.isArray(raw.shelf) ? raw.shelf : []).filter((id) => FLOWER_IDS.has(id)),
      auction: (() => {
        const a = isObj(raw.auction) ? raw.auction : {};
        const rl = isObj(a.lot) ? a.lot : null;
        const lot = rl && (rl.kind === "craft" && CRAFT_IDS.has(rl.id) || rl.kind === "petal" && FLOWER_IDS.has(rl.id)) ? {
          kind: rl.kind,
          id: rl.id,
          name: typeof rl.name === "string" ? rl.name : "",
          quality: typeof rl.quality === "string" ? rl.quality : "",
          base: Math.max(1, intOf(rl.base, 1))
        } : null;
        const bids = (Array.isArray(a.bids) ? a.bids : []).filter(isObj).slice(0, 3).map((b) => ({
          name: typeof b.name === "string" ? b.name : "客人",
          price: Math.max(0, intOf(b.price, 0))
        }));
        return {
          day: typeof a.day === "string" ? a.day : "",
          consigned: Math.max(0, intOf(a.consigned, 0)),
          lot: bids.length ? lot : null,
          bids: lot ? bids : [],
          rerolls: Math.max(0, intOf(a.rerolls, 0))
        };
      })(),
      stats: (() => {
        const r = isObj(raw.stats) ? raw.stats : {};
        return {
          opened: Math.max(0, intOf(r.opened, 0)),
          todayCount: Math.max(0, intOf(r.todayCount, 0)),
          today: typeof r.today === "string" ? r.today : "",
          refreshUsed: r.refreshUsed === true
        };
      })(),
      supply: (() => {
        var _a, _b;
        const r = isObj(raw.supply) ? raw.supply : {};
        const prices = {};
        for (const p of PODS) prices[p.id] = Math.max(1, intOf((_a = r.prices) == null ? void 0 : _a[p.id], p.price));
        const sold = {};
        for (const p of PODS) if (p.hidden === "milestone") sold[p.id] = Math.max(0, intOf((_b = r.sold) == null ? void 0 : _b[p.id], 0));
        return { day: typeof r.day === "string" ? r.day : "", prices, sold };
      })(),
      // 待选绽放结果：花 id 必须存在，品质以花表为准
      pending: (() => {
        if (!isObj(raw.pending)) return null;
        const f = FLOWERS.find((x) => x.id === raw.pending.flowerId);
        return f ? { flowerId: f.id, quality: f.quality } : null;
      })(),
      tutorialDone: raw.tutorialDone === true,
      // —— 《花匣·种子》——
      seeds: countsOf(raw.seeds, SEED_KEYS),
      boxProps: countsOf(raw.boxProps, BOX_PROP_IDS),
      boxStats: (() => {
        const r = isObj(raw.boxStats) ? raw.boxStats : {};
        const milestones = {};
        if (isObj(r.milestones)) {
          for (const k of Object.keys(r.milestones)) if (r.milestones[k]) milestones[k] = true;
        }
        return {
          opened: Math.max(0, intOf(r.opened, 0)),
          intact: Math.max(0, intOf(r.intact, 0)),
          broken: Math.max(0, intOf(r.broken, 0)),
          ruined: Math.max(0, intOf(r.ruined, 0)),
          milestones
        };
      })(),
      boxDecor: flagsOf(raw.boxDecor, DECOR_IDS),
      boxDaily: (() => {
        const r = isObj(raw.boxDaily) ? raw.boxDaily : {};
        return {
          day: typeof r.day === "string" ? r.day : "",
          freeUsed: Math.max(0, intOf(r.freeUsed, 0)),
          giftTaken: r.giftTaken === true,
          goldenQuota: r.goldenQuota === true
        };
      })(),
      ui: __spreadValues({}, base.ui),
      screen: "house"
    });
  }
  async function saveNow(sdk, s) {
    const value = __spreadValues({ v: SCHEMA_VERSION }, plainOf(s));
    try {
      if (!sdk) {
        memory = value;
        return;
      }
      await sdk.storage.set({ key: SAVE_KEY, value });
    } catch (e) {
      console.warn("[save] 存档失败", e);
    }
  }
  function createSaver(sdk, getState2) {
    let timer2 = null;
    const flush = () => {
      timer2 = null;
      return saveNow(sdk, getState2());
    };
    return {
      markDirty() {
        if (!timer2) timer2 = setTimeout(flush, 600);
      },
      flush() {
        if (timer2) {
          clearTimeout(timer2);
          timer2 = null;
        }
        return saveNow(sdk, getState2());
      }
    };
  }
  var saver = null;
  function setSaver(s) {
    saver = s;
  }
  function commit() {
    if (saver) saver.markDirty();
  }
  var podById = (id) => PODS.find((p) => p.id === id);
  var flowerById = (id) => FLOWERS.find((f) => f.id === id);
  var craftById = (id) => CRAFTS.find((c) => c.id === id);
  var petalsOf = (flowerId) => {
    var _a, _b;
    return (_b = (_a = getState().petals) == null ? void 0 : _a[flowerId]) != null ? _b : 0;
  };
  var normalPetalTotal = () => FLOWERS.filter((f) => f.quality === "normal").reduce((n, f) => n + petalsOf(f.id), 0);
  var tomorrowFlower = flowerOfTomorrow;
  var resinUnlocked = () => getState().totalEarned >= RESIN_UNLOCK_EARN;
  function soldToday(id) {
    var _a, _b;
    return (_b = (_a = getState().supply.sold) == null ? void 0 : _a[id]) != null ? _b : 0;
  }
  function podStockLeft(cfg) {
    var _a;
    if (cfg.hidden !== "milestone") return Infinity;
    return Math.max(0, ((_a = cfg.stock) != null ? _a : TIMELESS_DAILY_STOCK) - soldToday(cfg.id));
  }
  function availablePods(s = getState()) {
    const day = s.supply.day || dayKey();
    return PODS.filter((p) => {
      var _a, _b, _c, _d;
      if (!p.hidden) return true;
      if (p.hidden === "guest") return goldenGuestToday(day) || ((_a = s.boxDaily) == null ? void 0 : _a.goldenQuota) === true;
      if (p.hidden === "milestone") {
        const left = Math.max(0, ((_b = p.stock) != null ? _b : TIMELESS_DAILY_STOCK) - ((_d = (_c = s.supply.sold) == null ? void 0 : _c[p.id]) != null ? _d : 0));
        return s.stats.opened >= TIMELESS_UNLOCK_OPENS && left > 0;
      }
      return false;
    });
  }
  var timelessUnlocked = () => getState().stats.opened >= TIMELESS_UNLOCK_OPENS;
  var timelessNeed = () => Math.max(0, TIMELESS_UNLOCK_OPENS - getState().stats.opened);
  var goldenGuestHere = () => {
    var _a;
    const s = getState();
    return goldenGuestToday(s.supply.day || dayKey()) || ((_a = s.boxDaily) == null ? void 0 : _a.goldenQuota) === true;
  };
  function newDayCheck() {
    const s = getState();
    const today = dayKey();
    if (s.stats.today === today) return;
    setState((st) => ({
      stats: __spreadProps(__spreadValues({}, st.stats), { today, todayCount: 0, refreshUsed: false }),
      supply: { day: today, prices: rollPrices(), sold: {} },
      boxDaily: { day: today, freeUsed: 0, giftTaken: false, goldenQuota: false },
      auction: __spreadProps(__spreadValues({}, st.auction), { day: today, consigned: 0, rerolls: 0 })
    }));
    commit();
  }
  function rollPrices() {
    const prices = {};
    for (const p of PODS) {
      const factor = 1 - PRICE_SWING + Math.random() * PRICE_SWING * 2;
      prices[p.id] = Math.max(1, Math.round(p.price * factor));
    }
    return prices;
  }
  function priceOf(type) {
    var _a;
    return (_a = getState().supply.prices[type]) != null ? _a : podById(type).price;
  }
  function refreshSupply() {
    const s = getState();
    const free = !s.stats.refreshUsed;
    if (!free && s.coin < REFRESH_COST) return { ok: false, reason: "poor" };
    setState((st) => ({
      coin: st.coin - (free ? 0 : REFRESH_COST),
      stats: __spreadProps(__spreadValues({}, st.stats), { refreshUsed: true }),
      supply: __spreadProps(__spreadValues({}, st.supply), { prices: rollPrices() })
    }));
    commit();
    return { ok: true, free };
  }
  function buyPods(types) {
    var _a, _b, _c, _d;
    const s = getState();
    const avail = new Set(availablePods(s).map((p) => p.id));
    const left = {};
    const items = [];
    let skipped = 0;
    for (const t of types) {
      const cfg = podById(t);
      if (!cfg || !avail.has(t)) {
        skipped += 1;
        continue;
      }
      if (cfg.hidden === "milestone") {
        if (((_b = left[t]) != null ? _b : ((_a = cfg.stock) != null ? _a : TIMELESS_DAILY_STOCK) - soldToday(t)) <= 0) {
          skipped += 1;
          continue;
        }
        left[t] = ((_d = left[t]) != null ? _d : ((_c = cfg.stock) != null ? _c : TIMELESS_DAILY_STOCK) - soldToday(t)) - 1;
      }
      items.push({ type: t, price: priceOf(t) });
    }
    if (items.length === 0) return { ok: false, reason: skipped ? "soldout" : "empty" };
    const total = items.reduce((n, it) => n + it.price, 0);
    if (s.coin < total) return { ok: false, reason: "poor" };
    const now = Date.now();
    const bought = items.map((it, i) => ({
      uid: `${now}_${i}_${Math.random().toString(36).slice(2, 7)}`,
      type: it.type,
      peeled: false,
      boughtAt: now,
      boughtPrice: it.price
    }));
    setState((st) => {
      var _a2, _b2;
      const sold = __spreadValues({}, (_a2 = st.supply.sold) != null ? _a2 : {});
      for (const it of items) {
        const cfg = podById(it.type);
        if ((cfg == null ? void 0 : cfg.hidden) === "milestone") sold[cfg.id] = ((_b2 = sold[cfg.id]) != null ? _b2 : 0) + 1;
      }
      return {
        coin: st.coin - total,
        pods: [...st.pods, ...bought],
        supply: __spreadProps(__spreadValues({}, st.supply), { sold })
      };
    });
    commit();
    return { ok: true, bought, total, skipped };
  }
  function sowSeed(kind) {
    var _a;
    const key = kind === "intact" ? "intact" : "broken";
    const s = getState();
    if (((_a = s.seeds[key]) != null ? _a : 0) < 1) return { ok: false, reason: "none" };
    const pool = availablePods(s).filter((p) => !p.hidden);
    if (!pool.length) return { ok: false, reason: "empty" };
    const cfg = pool[Math.floor(Math.random() * pool.length)];
    const now = Date.now();
    const pod = {
      uid: `sown_${now}_${Math.random().toString(36).slice(2, 7)}`,
      type: cfg.id,
      peeled: true,
      damaged: key === "broken",
      boughtAt: now,
      boughtPrice: 0
    };
    setState((st) => {
      var _a2;
      return {
        seeds: __spreadProps(__spreadValues({}, st.seeds), { [key]: Math.max(0, ((_a2 = st.seeds[key]) != null ? _a2 : 0) - 1) }),
        pods: [...st.pods, pod]
      };
    });
    commit();
    return { ok: true, pod };
  }
  function sowAndStart(kind) {
    const r = sowSeed(kind);
    if (!r.ok) {
      toast(r.reason === "empty" ? "今天没有可以下种的常规种荚" : `没有${kind === "intact" ? "完好" : "破损"}种子可种`, "bad");
      return false;
    }
    sfx.seed();
    toast(kind === "intact" ? "完好种子种下了，去浇水培育" : "破损种子勉强种下了，品质会降一档", "info");
    startFlow(r.pod.uid);
    return true;
  }
  function refundPod(uid) {
    const s = getState();
    const pod = s.pods.find((p) => p.uid === uid);
    if (!pod || pod.peeled || Date.now() - pod.boughtAt > REFUND_WINDOW_MS) return { ok: false };
    setState((st) => ({
      coin: st.coin + pod.boughtPrice,
      pods: st.pods.filter((p) => p.uid !== uid)
    }));
    commit();
    return { ok: true, amount: pod.boughtPrice };
  }
  function recentBuyablePods() {
    const now = Date.now();
    return getState().pods.filter((p) => !p.peeled && now - p.boughtAt <= REFUND_WINDOW_MS);
  }
  function openPod(uid) {
    const pod = getState().pods.find((p) => p.uid === uid);
    return pod ? __spreadValues({}, pod) : null;
  }
  function markPeeled(uid) {
    setState((st) => ({ pods: st.pods.map((p) => p.uid === uid ? __spreadProps(__spreadValues({}, p), { peeled: true }) : p) }));
    commit();
  }
  function rollQuality(prob) {
    const r = Math.random();
    if (r < prob.variant) return "variant";
    if (r < prob.variant + prob.rare) return "rare";
    return "normal";
  }
  function resolveGrow(uid, damaged) {
    const s = getState();
    const pod = s.pods.find((p) => p.uid === uid);
    if (!pod) return null;
    const cfg = podById(pod.type);
    setState((st) => ({
      pods: st.pods.filter((p) => p.uid !== uid),
      stats: __spreadProps(__spreadValues({}, st.stats), { opened: st.stats.opened + 1, todayCount: st.stats.todayCount + 1 })
    }));
    if (cfg.dead > 0 && Math.random() < cfg.dead) {
      commit();
      return { dead: true };
    }
    let quality = rollQuality(cfg.prob);
    if (damaged) quality = quality === "variant" ? "rare" : "normal";
    const pool = FLOWERS.filter((f) => f.quality === quality);
    const flower = pool[Math.floor(Math.random() * pool.length)];
    setState((st) => ({ pending: { flowerId: flower.id, quality } }));
    commit();
    return { dead: false, flower, quality };
  }
  function chooseHarvest() {
    const s = getState();
    if (!s.pending) return;
    const { flowerId } = s.pending;
    setState((st) => {
      var _a;
      return {
        pending: null,
        illustrated: __spreadProps(__spreadValues({}, st.illustrated), { [flowerId]: true }),
        petals: __spreadProps(__spreadValues({}, st.petals), { [flowerId]: ((_a = st.petals[flowerId]) != null ? _a : 0) + 1 })
      };
    });
    commit();
  }
  function chooseKeep() {
    const s = getState();
    if (!s.pending) return;
    const { flowerId } = s.pending;
    if (s.shelf.includes(flowerId)) {
      setState((st) => ({
        pending: null,
        illustrated: __spreadProps(__spreadValues({}, st.illustrated), { [flowerId]: true })
      }));
      commit();
      return;
    }
    setState((st) => ({
      pending: null,
      illustrated: __spreadProps(__spreadValues({}, st.illustrated), { [flowerId]: true }),
      shelf: [...st.shelf, flowerId]
    }));
    commit();
  }
  function craftable(recipe) {
    const s = getState();
    const flowerOk = recipe.need.anyNormal ? normalPetalTotal() >= recipe.need.anyNormal : petalsOf(recipe.need.flower) >= recipe.need.n;
    const consumOk = Object.entries(recipe.consum).every(([k, n]) => {
      var _a;
      return ((_a = s.consumables[k]) != null ? _a : 0) >= n;
    });
    return flowerOk && consumOk && s.coin >= recipe.fee;
  }
  function craftNeeds(recipe) {
    var _a;
    const s = getState();
    const list = [];
    if (recipe.need.anyNormal) {
      list.push({ label: `任意普通花瓣 ×${recipe.need.anyNormal}`, ok: normalPetalTotal() >= recipe.need.anyNormal });
    } else {
      const f = flowerById(recipe.need.flower);
      list.push({ label: `${f.name}${QUALITY[f.quality].material} ×${recipe.need.n}`, ok: petalsOf(f.id) >= recipe.need.n });
    }
    for (const [k, n] of Object.entries(recipe.consum)) {
      list.push({ label: `${CONSUMABLES[k].name} ×${n}`, ok: ((_a = s.consumables[k]) != null ? _a : 0) >= n });
    }
    list.push({ label: `工坊费 ${recipe.fee} 币`, ok: s.coin >= recipe.fee });
    return list;
  }
  function doCraft(recipeId) {
    const recipe = craftById(recipeId);
    if (!recipe || !craftable(recipe)) return { ok: false, reason: "materials" };
    setState((st) => {
      var _a, _b, _c;
      const petals = __spreadValues({}, st.petals);
      if (recipe.need.anyNormal) {
        let left = recipe.need.anyNormal;
        for (const f of FLOWERS.filter((x) => x.quality === "normal")) {
          const take = Math.min(left, (_a = petals[f.id]) != null ? _a : 0);
          if (take > 0) {
            petals[f.id] -= take;
            left -= take;
          }
          if (!left) break;
        }
      } else {
        petals[recipe.need.flower] = ((_b = petals[recipe.need.flower]) != null ? _b : 0) - recipe.need.n;
      }
      const consumables = __spreadValues({}, st.consumables);
      for (const [k, n] of Object.entries(recipe.consum)) consumables[k] -= n;
      return {
        petals,
        consumables,
        coin: st.coin - recipe.fee,
        crafts: __spreadProps(__spreadValues({}, st.crafts), { [recipe.id]: ((_c = st.crafts[recipe.id]) != null ? _c : 0) + 1 })
      };
    });
    commit();
    return { ok: true, recipe };
  }
  function sellCraft(id) {
    var _a;
    const s = getState();
    if (((_a = s.crafts[id]) != null ? _a : 0) < 1) return { ok: false };
    const recipe = craftById(id);
    setState((st) => ({
      crafts: __spreadProps(__spreadValues({}, st.crafts), { [id]: st.crafts[id] - 1 }),
      coin: st.coin + recipe.sell,
      totalEarned: st.totalEarned + recipe.sell
    }));
    commit();
    return { ok: true, amount: recipe.sell };
  }
  function sellPetals(flowerId, n) {
    var _a;
    const s = getState();
    const have = (_a = s.petals[flowerId]) != null ? _a : 0;
    const cnt = Math.min(n, have);
    if (cnt <= 0) return { ok: false };
    const f = flowerById(flowerId);
    const amount = cnt * MATERIAL_VALUE[f.quality];
    setState((st) => ({
      petals: __spreadProps(__spreadValues({}, st.petals), { [flowerId]: have - cnt }),
      coin: st.coin + amount,
      totalEarned: st.totalEarned + amount
    }));
    commit();
    return { ok: true, amount, cnt };
  }
  function buyConsumable(id) {
    const s = getState();
    const c = CONSUMABLES[id];
    if (s.coin < c.price) return { ok: false, reason: "poor" };
    setState((st) => {
      var _a;
      return {
        coin: st.coin - c.price,
        consumables: __spreadProps(__spreadValues({}, st.consumables), { [id]: ((_a = st.consumables[id]) != null ? _a : 0) + 1 })
      };
    });
    commit();
    return { ok: true };
  }
  function finishTutorial() {
    setState((st) => ({ tutorialDone: true }));
    commit();
  }
  function boxFreeLeft() {
    var _a, _b;
    const s = getState();
    return Math.max(0, BOX_DAILY_FREE - ((_b = (_a = s.boxDaily) == null ? void 0 : _a.freeUsed) != null ? _b : 0));
  }
  var boxCost = () => boxFreeLeft() > 0 ? 0 : BOX_PRICE;
  var boxAffordable = () => {
    const c = boxCost();
    return c === 0 || getState().coin >= c;
  };
  var boxDecorCount = () => {
    var _a;
    return Object.keys((_a = getState().boxDecor) != null ? _a : {}).length;
  };
  function safeZone(props) {
    const pad = (props != null ? props : []).includes("torch") ? TORCH_PAD : 0;
    const lo = Math.max(ANGLE_TOO_TIGHT, INTACT_LO - pad);
    const hi = Math.min(ANGLE_DANGER, INTACT_HI + pad);
    return { lo, hi, center: Math.round((lo + hi) / 2) };
  }
  function angleOutcome(angle, props) {
    if (angle < ANGLE_TOO_TIGHT) return "tight";
    const z = safeZone(props);
    if (angle <= z.lo) return "tight";
    if (angle <= z.hi) return "intact";
    if (angle <= ANGLE_DANGER) return "broken";
    return "ruined";
  }
  function angleBand(angle) {
    var _a;
    if (angle < ANGLE_TOO_TIGHT) return { label: "卡住", cell: -1 };
    const band = (_a = ANGLE_BANDS.find((b) => angle <= b.max)) != null ? _a : ANGLE_BANDS[ANGLE_BANDS.length - 1];
    return { label: band.label, cell: band.cell };
  }
  function settleCasket(angle, props) {
    if (angle < ANGLE_TOO_TIGHT) return { result: "tight" };
    const s = getState();
    const freeLeft = boxFreeLeft();
    const cost = freeLeft > 0 ? 0 : BOX_PRICE;
    if (cost > 0 && s.coin < cost) return { result: "poor" };
    const used = (props != null ? props : []).filter((id) => {
      var _a;
      return ((_a = s.boxProps[id]) != null ? _a : 0) > 0;
    });
    let result = angleOutcome(angle, used);
    if (result === "tight") return { result: "tight" };
    if (used.includes("cloth") && result === "ruined") result = "broken";
    setState((st) => {
      var _a, _b, _c, _d, _e, _f;
      const seeds = __spreadValues({}, st.seeds);
      const boxProps = __spreadValues({}, st.boxProps);
      for (const id of used) boxProps[id] = Math.max(0, ((_a = boxProps[id]) != null ? _a : 0) - 1);
      if (result === "intact") seeds.intact += 1;
      else if (result === "broken") seeds.broken += 1;
      const boxStats = __spreadProps(__spreadValues({}, st.boxStats), {
        opened: ((_b = st.boxStats.opened) != null ? _b : 0) + 1,
        intact: ((_c = st.boxStats.intact) != null ? _c : 0) + (result === "intact" ? 1 : 0),
        broken: ((_d = st.boxStats.broken) != null ? _d : 0) + (result === "broken" ? 1 : 0),
        ruined: ((_e = st.boxStats.ruined) != null ? _e : 0) + (result === "ruined" ? 1 : 0)
      });
      const boxDaily = __spreadValues({}, st.boxDaily);
      if (freeLeft > 0) boxDaily.freeUsed = ((_f = boxDaily.freeUsed) != null ? _f : 0) + 1;
      return { seeds, boxProps, boxStats, boxDaily, coin: st.coin - cost };
    });
    commit();
    return { result, used, cost };
  }
  function usePaste() {
    var _a, _b;
    const s = getState();
    if (((_a = s.boxProps.paste) != null ? _a : 0) < 1 || ((_b = s.seeds.broken) != null ? _b : 0) < 1) return { ok: false };
    setState((st) => {
      var _a2, _b2;
      return {
        boxProps: __spreadProps(__spreadValues({}, st.boxProps), { paste: st.boxProps.paste - 1 }),
        seeds: { intact: st.seeds.intact + 1, broken: st.seeds.broken - 1 },
        boxStats: __spreadProps(__spreadValues({}, st.boxStats), { intact: ((_a2 = st.boxStats.intact) != null ? _a2 : 0) + 1, broken: Math.max(0, ((_b2 = st.boxStats.broken) != null ? _b2 : 0) - 1) })
      };
    });
    commit();
    return { ok: true };
  }
  function boxGiftSize() {
    return Math.min(DECOR_GIFT_CAP, BOX_GIFT_BASE + boxDecorCount() * DECOR_GIFT_BONUS);
  }
  function boxGiftReady() {
    var _a;
    const s = getState();
    return ((_a = s.boxDaily) == null ? void 0 : _a.giftTaken) !== true;
  }
  function takeBoxGift() {
    var _a;
    const s = getState();
    if (!boxGiftReady()) return { ok: false };
    const pool = [...PRE_GIFT_POOL];
    const got = {};
    const n = boxGiftSize();
    for (let i = 0; i < n; i += 1) {
      const id = pool[Math.floor(Math.random() * pool.length)];
      got[id] = ((_a = got[id]) != null ? _a : 0) + 1;
    }
    setState((st) => {
      var _a2;
      const boxProps = __spreadValues({}, st.boxProps);
      for (const [k, v] of Object.entries(got)) boxProps[k] = ((_a2 = boxProps[k]) != null ? _a2 : 0) + v;
      return { boxProps, boxDaily: __spreadProps(__spreadValues({}, st.boxDaily), { giftTaken: true }) };
    });
    commit();
    return { ok: true, got };
  }
  var PRE_GIFT_POOL = ["torch", "lens", "cloth", "dew", "paste"];
  function buyBoxProp(id) {
    const cfg = BOX_PROPS[id];
    if (!cfg) return { ok: false };
    const s = getState();
    if (s.coin < cfg.price) return { ok: false, reason: "poor" };
    setState((st) => {
      var _a;
      return {
        coin: st.coin - cfg.price,
        boxProps: __spreadProps(__spreadValues({}, st.boxProps), { [id]: ((_a = st.boxProps[id]) != null ? _a : 0) + 1 })
      };
    });
    commit();
    return { ok: true };
  }
  function seedExchangeCan(id) {
    var _a, _b, _c, _d;
    const r = SEED_EXCHANGES.find((x) => x.id === id);
    if (!r) return false;
    const s = getState();
    return ((_a = r.need.intact) != null ? _a : 0) <= ((_b = s.seeds.intact) != null ? _b : 0) && ((_c = r.need.broken) != null ? _c : 0) <= ((_d = s.seeds.broken) != null ? _d : 0);
  }
  function seedExchange(id) {
    const r = SEED_EXCHANGES.find((x) => x.id === id);
    if (!r || !seedExchangeCan(id)) return { ok: false };
    setState((st) => {
      var _a, _b, _c, _d, _e, _f;
      const seeds = __spreadValues({}, st.seeds);
      seeds.intact -= (_a = r.need.intact) != null ? _a : 0;
      seeds.broken -= (_b = r.need.broken) != null ? _b : 0;
      const consumables = __spreadValues({}, st.consumables);
      for (const [k, v] of Object.entries((_c = r.gain.consumables) != null ? _c : {})) consumables[k] = ((_d = consumables[k]) != null ? _d : 0) + v;
      const boxDaily = __spreadValues({}, st.boxDaily);
      if (r.gain.goldenQuota) boxDaily.goldenQuota = true;
      return { seeds, consumables, boxDaily, coin: st.coin + ((_e = r.gain.coin) != null ? _e : 0), totalEarned: st.totalEarned + ((_f = r.gain.coin) != null ? _f : 0) };
    });
    commit();
    return { ok: true, gain: r.gain };
  }
  function decorCan(id) {
    var _a, _b, _c, _d, _e;
    const d = BOX_DECOR[id];
    if (!d) return false;
    const s = getState();
    if ((_a = s.boxDecor) == null ? void 0 : _a[id]) return false;
    return ((_b = d.need.intact) != null ? _b : 0) <= ((_c = s.seeds.intact) != null ? _c : 0) && ((_d = d.need.broken) != null ? _d : 0) <= ((_e = s.seeds.broken) != null ? _e : 0);
  }
  function buyDecor(id) {
    const d = BOX_DECOR[id];
    if (!decorCan(id)) return { ok: false };
    setState((st) => {
      var _a, _b;
      const seeds = __spreadValues({}, st.seeds);
      seeds.intact -= (_a = d.need.intact) != null ? _a : 0;
      seeds.broken -= (_b = d.need.broken) != null ? _b : 0;
      return { seeds, boxDecor: __spreadProps(__spreadValues({}, st.boxDecor), { [id]: true }) };
    });
    commit();
    return { ok: true };
  }
  function checkBoxMilestones() {
    var _a, _b;
    const s = getState();
    const opened = (_b = (_a = s.boxStats) == null ? void 0 : _a.opened) != null ? _b : 0;
    const hit = [];
    setState((st) => {
      var _a2, _b2;
      const milestones = __spreadValues({}, (_a2 = st.boxStats.milestones) != null ? _a2 : {});
      const boxProps = __spreadValues({}, st.boxProps);
      let changed = false;
      for (const m of BOX_MILESTONES) {
        if (opened >= m.at && !milestones[m.at]) {
          milestones[m.at] = true;
          for (const [k, v] of Object.entries(m.props)) boxProps[k] = ((_b2 = boxProps[k]) != null ? _b2 : 0) + v;
          hit.push(m.note);
          changed = true;
        }
      }
      return changed ? { boxStats: __spreadProps(__spreadValues({}, st.boxStats), { milestones }), boxProps } : {};
    });
    if (hit.length) commit();
    return hit;
  }
  function h(tag, attrs = {}, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs != null ? attrs : {})) {
      if (v == null || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "html") el.innerHTML = v;
      else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === "dataset") Object.assign(el.dataset, v);
      else el.setAttribute(k, v === true ? "" : v);
    }
    for (const c of children.flat(Infinity)) {
      if (c == null || c === false) continue;
      el.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return el;
  }
  function img(src, cls, alt = "") {
    const im = h("img", { src, alt, class: `${cls} art`, draggable: "false" });
    im.loading = "eager";
    im.decoding = "async";
    if (im.complete && im.naturalWidth > 0) im.classList.add("ready");
    else {
      im.addEventListener("load", () => im.classList.add("ready"), { once: true });
      im.addEventListener("error", () => im.classList.add("ready"), { once: true });
    }
    return im;
  }
  var root = null;
  function bindModalRoot(el) {
    root = el;
  }
  function closeModal() {
    if (root) root.replaceChildren();
  }
  function showModal({ title, body, actions = [], className = "", dismissable = true }) {
    if (!root) return;
    root.replaceChildren();
    const card = h(
      "div",
      { class: `modal-card ${className}` },
      title != null && h("div", { class: "modal-title" }, title),
      body && h("div", { class: "modal-body" }, body),
      actions.length > 0 && h(
        "div",
        { class: "modal-actions" },
        actions.map((a) => {
          var _a, _b;
          return h("button", {
            class: `btn ${(_a = a.kind) != null ? _a : "primary"}`,
            disabled: (_b = a.disabled) != null ? _b : false,
            onClick: () => {
              var _a2;
              if (a.keepOpen !== true) closeModal();
              (_a2 = a.onClick) == null ? void 0 : _a2.call(a);
            }
          }, a.label);
        })
      )
    );
    const overlay = h("div", {
      class: "modal-overlay",
      onClick: dismissable ? (e) => {
        if (e.target === e.currentTarget) closeModal();
      } : null
    }, card);
    root.append(overlay);
  }
  var toastTimer = null;
  function toast(msg, kind = "info") {
    const tr = document.getElementById("toast-root");
    if (!tr) return;
    tr.replaceChildren();
    const t = h("div", { class: `toast toast-${kind}` }, msg);
    tr.append(t);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      t.classList.add("out");
      setTimeout(() => t.remove(), 320);
    }, 1800);
  }
  var ctx = null;
  function ac() {
    try {
      if (!ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        ctx = new AC();
      }
      if (ctx.state === "suspended") ctx.resume().catch(() => {
      });
      return ctx;
    } catch (e) {
      return null;
    }
  }
  function tone({ f = 440, t = 0.12, type = "sine", g = 0.05, delay = 0, slide = 0 }) {
    const c = ac();
    if (!c) return;
    try {
      const o = c.createOscillator();
      const gn = c.createGain();
      const t0 = c.currentTime + delay;
      o.type = type;
      o.frequency.setValueAtTime(f, t0);
      if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, f + slide), t0 + t);
      gn.gain.setValueAtTime(1e-4, t0);
      gn.gain.exponentialRampToValueAtTime(g, t0 + 0.012);
      gn.gain.exponentialRampToValueAtTime(1e-4, t0 + t);
      o.connect(gn);
      gn.connect(c.destination);
      o.start(t0);
      o.stop(t0 + t + 0.05);
    } catch (e) {
    }
  }
  var sfx = {
    click() {
      tone({ f: 520, t: 0.05, type: "triangle", g: 0.028 });
    },
    peel() {
      tone({ f: 300 + Math.random() * 90, t: 0.08, type: "triangle", g: 0.05, slide: -140 });
    },
    seed() {
      tone({ f: 660, t: 0.14, g: 0.045 });
      tone({ f: 880, t: 0.16, g: 0.035, delay: 0.08 });
    },
    water() {
      tone({ f: 230, t: 0.28, g: 0.045, slide: 170 });
    },
    bloom() {
      [523, 659, 784, 1047].forEach((f, i) => tone({ f, t: 0.22, g: 0.05, delay: i * 0.09 }));
    },
    dead() {
      tone({ f: 220, t: 0.42, type: "sawtooth", g: 0.028, slide: -130 });
    },
    coin() {
      tone({ f: 988, t: 0.07, type: "square", g: 0.026 });
      tone({ f: 1319, t: 0.12, type: "square", g: 0.026, delay: 0.06 });
    },
    craft() {
      tone({ f: 440, t: 0.1, g: 0.04 });
      tone({ f: 587, t: 0.12, g: 0.04, delay: 0.1 });
      tone({ f: 880, t: 0.16, g: 0.04, delay: 0.2 });
    }
  };
  var queued = /* @__PURE__ */ new Set();
  var idle = window.requestIdleCallback ? (fn) => window.requestIdleCallback(fn, { timeout: 900 }) : (fn) => setTimeout(fn, 220);
  function push(url) {
    if (typeof url !== "string" || !url || queued.has(url)) return;
    queued.add(url);
    const im = new Image();
    im.decoding = "async";
    im.src = url;
  }
  function pushMany(urls) {
    for (const u of urls) push(u);
  }
  function allOf(group) {
    const src = ART[group];
    return src ? Object.values(src) : [];
  }
  function warmCritical() {
    push(ART.hero);
    pushMany(allOf("pods"));
    idle(() => {
      pushMany(allOf("scenes"));
      pushMany(allOf("flowers"));
    });
    idle(() => {
      push(ART.box.closed);
      push(ART.box.states.url);
      push(ART.seeds.url);
      push(ART.props.url);
    });
  }
  function warmForScreen() {
    const s = getState();
    idle(() => {
      switch (s.screen) {
        case "house":
          pushMany(s.pods.map((p) => ART.pods[p.type]));
          pushMany(s.shelf.map((id) => ART.flowers[id]));
          break;
        case "market":
          pushMany(allOf("pods"));
          pushMany(Object.keys(ART.crafts).map((k) => ART.crafts[k]));
          break;
        case "workshop":
          pushMany(allOf("flowers"));
          pushMany(Object.keys(ART.crafts).map((k) => ART.crafts[k]));
          break;
        case "album":
          pushMany(allOf("flowers"));
          break;
        case "casket":
          push(ART.box.closed);
          push(ART.box.states.url);
          push(ART.seeds.url);
          push(ART.props.url);
          break;
        default:
          pushMany(allOf("flowers"));
          pushMany(allOf("pods"));
      }
    });
  }
  function warmFlow(podType) {
    push(ART.pods[podType]);
    idle(() => pushMany(allOf("flowers")));
  }
  var SHELL_COLORS = ["#B79A6B", "#8F7350", "#C9B28A", "#A5834B"];
  var PETAL_COLORS = ["#E8B4B8", "#C9A45C", "#B48EAD", "#EFA9A0", "#9FB8D8"];
  var ASH_COLORS = ["#8C8071", "#6B6257", "#A99E8C"];
  var session = null;
  var timer = null;
  var podOpening = null;
  var skipPodOnce = false;
  function startFlow(uid) {
    const pod = openPod(uid);
    if (!pod) {
      toast("这枚种荚已经不在背包里了", "bad");
      return;
    }
    warmFlow(pod.type);
    clearTimer();
    session = {
      uid,
      type: pod.type,
      phase: pod.peeled ? "ready" : "peel",
      damaged: pod.damaged === true,
      n: 0,
      watering: false,
      result: null,
      modalShown: false
    };
    closeModal();
    if (pod.peeled) {
      podOpening = null;
      setState({ screen: "flow" });
      return;
    }
    skipPodOnce = false;
    podOpening = uid;
    session2 = newSession();
    setState({ screen: "casket", ui: __spreadProps(__spreadValues({}, getState().ui), { casketTab: "open" }) });
  }
  function finishPodOpen(damaged) {
    const uid = podOpening;
    podOpening = null;
    session2 = newSession();
    if (!session) {
      setState({ screen: "house" });
      return;
    }
    if (damaged === "ruined") {
      const r = resolveGrow(uid);
      if (r && !r.dead) setState({ pending: null });
      session.phase = "dead";
    } else {
      markPeeled(uid);
      session.damaged = damaged === "broken";
      session.phase = "grow";
      session.watering = false;
    }
    session.settling = false;
    session.growEndsAt = null;
    setState({ screen: "flow" });
  }
  function cancelPodOpen() {
    podOpening = null;
    session2 = newSession();
    endFlow();
  }
  function resumePending() {
    const p = getState().pending;
    if (!p) return false;
    clearTimer();
    session = {
      uid: null,
      type: null,
      phase: "bloom",
      watering: false,
      result: { flowerId: p.flowerId, quality: p.quality },
      modalShown: false
    };
    return true;
  }
  function hasSession() {
    return !!session;
  }
  function isSettling() {
    return !!(session == null ? void 0 : session.settling);
  }
  function flowLocked() {
    if (!session) return false;
    return !!(session.watering || session.settling) || session.phase === "bloom" || session.phase === "dead";
  }
  function endFlow() {
    clearTimer();
    session = null;
    setState({ screen: "house" });
  }
  function resetGame() {
    clearTimer();
    closeModal();
    session = null;
    session2 = null;
    podOpening = null;
    skipPodOnce = false;
    cart = [];
    clearTicks();
    const fresh = initialState();
    fresh.stats.today = dayKey();
    fresh.supply = { day: dayKey(), prices: rollPrices(), sold: {} };
    fresh.boxDaily = __spreadProps(__spreadValues({}, fresh.boxDaily), { day: dayKey() });
    fresh.auction = { day: dayKey(), consigned: 0, lot: null, bids: [] };
    replaceAll(fresh);
    if (saver) saver.flush();
    toast("花坊重新开张了，从头再来一局", "gold");
  }
  function confirmRestart() {
    showModal({
      title: "破产重来",
      body: h(
        "div",
        { style: "text-align:center;font-size:13px;line-height:1.75;color:var(--ink-2)" },
        "确定要把花坊清空重来吗？",
        h("br"),
        h("b", { style: "color:var(--ink)" }, "花铜币、种荚、花材、成品、花房陈列、花谱和花匣进度"),
        "都会归零，回到开局状态。",
        h("br"),
        "这个操作不能撤销。"
      ),
      actions: [
        { label: "再想想" },
        { label: "确定重来", kind: "gold", onClick: () => resetGame() }
      ]
    });
  }
  function clearTimer() {
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
    growView = null;
    growRerender = null;
  }
  function renderFlow(el, rerender) {
    if (!session) {
      clearTimer();
      if (resumePending()) {
        renderFlow(el, rerender);
        return;
      }
      el.append(h(
        "div",
        { class: "card", style: "margin-top:20px;text-align:center" },
        h("div", { class: "flow-hint" }, "这一荚已经收好啦。"),
        h("button", {
          class: "btn",
          style: "margin-top:12px",
          onClick: () => {
            sfx.click();
            setState({ screen: "house" });
          }
        }, "回花房")
      ));
      return;
    }
    const cfg = session.type ? podById(session.type) : null;
    const canBack = session.phase === "peel" || session.phase === "ready" || session.phase === "grow" && !session.watering || session.phase === "bloom" || session.phase === "dead";
    const head = h(
      "div",
      { class: "flow-top" },
      canBack ? h("button", { class: "btn small ghost", onClick: () => {
        sfx.click();
        endFlow();
      } }, "← 返回") : h("span", { style: "width:64px" }),
      h("div", { class: "flow-title" }, titleText()),
      h("span", { style: "width:64px" })
    );
    const stage = h("div", { class: "flow-stage" });
    el.append(h("div", { class: "flow" }, head, stage));
    if (session.damaged && (session.phase === "grow" || session.phase === "bloom")) {
      el.append(h("div", { class: "flow-hint", style: "text-align:center;margin-top:-2px" }, "种球被荚壳刮伤过：结果品质会降一档"));
    }
    if (session.phase === "peel") renderPeel(stage, cfg, rerender);
    else if (session.phase === "ready") renderReady(stage, cfg, rerender);
    else if (session.phase === "grow") renderGrow(stage, cfg, rerender);
    else if (session.phase === "dead") renderDead(stage, cfg, rerender);
    else if (session.phase === "bloom") renderBloom(stage, rerender);
  }
  function titleText() {
    const cfg = session.type ? podById(session.type) : null;
    switch (session.phase) {
      case "peel":
        return `${cfg.name} · 剥壳`;
      case "ready":
        return "种球露出来了";
      case "grow":
        return `${cfg.name} · 培育`;
      case "dead":
        return "培育失败";
      default:
        return "绽放时刻";
    }
  }
  function renderPeel(stage, cfg, rerender) {
    const podImg = img(ART.pods[session.type], "pod-img", cfg.name);
    const dotsEl = h("div", { class: "dots" });
    const label = h("div", { class: "flow-hint", style: "font-size:13.5px;color:var(--ink);font-weight:600" }, `剥离外壳 ${session.n}/${cfg.peel}`);
    const drawDots = () => {
      dotsEl.replaceChildren(...Array.from({ length: cfg.peel }, (_, i) => h("span", { class: `dot${i < session.n ? " on" : ""}` })));
    };
    drawDots();
    podImg.addEventListener("click", () => {
      if (session.phase !== "peel" || session.n >= cfg.peel) return;
      session.n += 1;
      sfx.peel();
      podImg.classList.remove("shake");
      void podImg.offsetWidth;
      podImg.classList.add("shake");
      podImg.style.filter = `brightness(${1 + session.n * 0.06})`;
      spawnBurst(podImg.parentElement, 6, SHELL_COLORS);
      drawDots();
      label.textContent = `剥离外壳 ${session.n}/${cfg.peel}`;
      if (session.n >= cfg.peel) {
        podImg.style.pointerEvents = "none";
        label.textContent = "种球露出来了…";
        session.settling = true;
        markPeeled(session.uid);
        setTimeout(() => {
          sfx.seed();
          session.phase = "ready";
          session.settling = false;
          rerender();
        }, 520);
      }
    });
    stage.append(
      h("div", { class: "pod-stage" }, podImg),
      label,
      dotsEl,
      h("div", { class: "flow-hint" }, "点一点，把外壳一片片剥下来。", h("br"), "轻一点，别伤着里面的种球。")
    );
  }
  function renderReady(stage, cfg, rerender) {
    stage.append(
      h(
        "div",
        { class: "pod-stage" },
        h("div", { class: "seed-ball" })
      ),
      h("div", { class: "flow-hint" }, `${cfg.name}剥完了，种球完好。`, h("br"), "浇水培育，等它发芽。"),
      h(
        "div",
        { style: "margin-top:14px" },
        h("button", { class: "btn", onClick: () => {
          session.phase = "grow";
          rerender();
        } }, "浇水培育")
      )
    );
  }
  function renderGrow(stage, cfg, rerender) {
    const sprout = h("div", { class: "sprout" });
    const potArea = h(
      "div",
      { class: "pot-area" },
      sprout,
      h("div", { class: "pot-rim" }),
      h("div", { class: "pot-body" })
    );
    let action;
    if (!session.watering) {
      action = h(
        "div",
        { style: "margin-top:16px" },
        h("button", {
          class: "btn gold",
          onClick: () => {
            session.watering = true;
            rerender();
          }
        }, "浇水培育"),
        h("div", { class: "flow-hint" }, cfg.dead > 0 ? `残损秘荚有 ${Math.round(cfg.dead * 100)}% 概率黑腐，是福是祸。` : "浇透水，等它慢慢发芽。")
      );
    } else {
      requestAnimationFrame(() => sprout.classList.add("grown"));
      const ring = h("div", { class: "ring" }, h("b", null, String(cfg.grow)));
      action = h(
        "div",
        { style: "margin-top:10px" },
        ring,
        h("div", { class: "flow-hint" }, "喝饱水的种子正在发芽…"),
        h("button", {
          class: "btn small ghost",
          style: "margin-top:8px",
          onClick: () => {
            clearTimer();
            finish(rerender);
          }
        }, "跳过")
      );
      armGrowClock(ring, cfg, rerender);
    }
    stage.append(h(
      "div",
      { class: "grow-stage" },
      img(ART.scenes.house, "stage-bg", "花房内部"),
      h("div", { class: "stage-veil" }),
      h("div", { class: "grow-inner" }, potArea, action)
    ));
  }
  var growView = null;
  var growRerender = null;
  function armGrowClock(ring, cfg, rerender) {
    const total = cfg.grow * 1e3;
    if (!session.growEndsAt) session.growEndsAt = Date.now() + total;
    growView = { ring, b: ring.querySelector("b"), total };
    growRerender = rerender;
    if (!timer) timer = setInterval(tickGrow, 100);
    tickGrow();
  }
  function tickGrow() {
    if (!session) {
      clearTimer();
      return;
    }
    const left = Math.max(0, session.growEndsAt - Date.now());
    const v = growView;
    if (v && v.ring.isConnected) {
      v.ring.style.setProperty("--p", String(100 * (1 - left / v.total)));
      if (v.b) v.b.textContent = String(Math.ceil(left / 1e3));
    }
    if (left <= 0) {
      const rerender = growRerender;
      clearTimer();
      finish(rerender);
    }
  }
  function finish(rerender) {
    if (!session) return;
    session.settling = true;
    const r = resolveGrow(session.uid, session.damaged);
    if (!r) {
      session.settling = false;
      if (resumePending()) {
        redraw(rerender);
        return;
      }
      toast("这一荚没能结成花，先回花房吧", "bad");
      endFlow();
      return;
    }
    session.watering = false;
    session.growEndsAt = null;
    if (r.dead) {
      session.phase = "dead";
    } else {
      session.result = { flowerId: r.flower.id, quality: r.quality };
      session.phase = "bloom";
    }
    session.settling = false;
    redraw(rerender);
  }
  function redraw(rerender) {
    if (typeof rerender === "function") rerender();
    else setState({ screen: "flow" });
  }
  function renderDead(stage, cfg, rerender) {
    const first = !session.deadPlayed;
    session.deadPlayed = true;
    if (first) sfx.dead();
    const host = h(
      "div",
      { class: "bloom-stage" },
      img(ART.pods[session.type], "bloom-img dead", cfg.name)
    );
    stage.append(
      host,
      h("div", { class: "flow-hint" }, "芽尖发黑了…这一荚没有收成。")
    );
    if (first) spawnBurst(host, 10, ASH_COLORS);
    if (!session.modalShown) {
      session.modalShown = true;
      setTimeout(() => {
        showModal({
          title: "培育失败",
          body: h(
            "div",
            { style: "text-align:center;font-size:13px;line-height:1.7;color:var(--ink-2)" },
            "种荚里的芽黑腐了，这一枚没有收成。",
            h("br"),
            h("span", { style: "color:var(--ink)" }, "花娘：残损秘荚就是这样的脾气，别灰心，下一枚会更好。")
          ),
          actions: [{ label: "知道了", onClick: () => endFlow() }]
        });
      }, 1100);
    }
    void rerender;
  }
  function renderBloom(stage, rerender) {
    const f = flowerById(session.result.flowerId);
    const q = QUALITY[session.result.quality];
    const first = !session.bloomPlayed;
    session.bloomPlayed = true;
    if (first) sfx.bloom();
    const host = h(
      "div",
      { class: "bloom-stage" },
      img(ART.flowers[f.id], "bloom-img", f.name)
    );
    stage.append(host, h("div", { class: "flow-hint" }, "花开的声音，只有花房里听得见。"));
    if (first) spawnBurst(host, 14, PETAL_COLORS);
    if (!session.modalShown) {
      session.modalShown = true;
      setTimeout(() => {
        const keepTaken = getState().shelf.includes(f.id);
        showModal({
          dismissable: false,
          body: h(
            "div",
            { class: "reveal" },
            h("div", { class: `qchip ribbon ${q.cls}` }, q.label + (session.result.quality === "variant" ? " · 鎏金档案" : "")),
            img(ART.flowers[f.id], "reveal-img", f.name),
            h("div", { class: "r-name" }, f.name),
            h("div", { class: "r-sub" }, `${q.label}花 · 已记入花谱`),
            h("div", { class: "sci" }, f.sci),
            session.result.quality === "variant" ? h("div", { class: "r-question" }, "变异花做滴胶最值钱，别急着按保底卖掉哦。") : h("div", { class: "r-question" }, "采收做成手作更值钱，收藏则摆进花房花架。"),
            keepTaken ? h("div", { class: "r-question", style: "color:var(--ink-2)" }, "这一种花已经摆在花架上了，每种花只能收藏一次。") : null
          ),
          actions: [
            {
              label: "采收",
              kind: "gold",
              onClick: () => {
                chooseHarvest();
                sfx.seed();
                toast(`${f.name}${q.material} ×1 已入包`);
                endFlow();
              }
            },
            // \u624B\u4E00\u6296\u70B9\u9519\u6536\u85CF\uFF1A\u5148\u5F39\u786E\u8BA4\uFF0C\u8BF4\u6E05\u695A\u6536\u85CF\u4E4B\u540E\u4E0D\u80FD\u5356
            keepTaken ? null : {
              label: "收藏",
              onClick: () => {
                showModal({
                  title: "确定要收藏吗？",
                  body: h(
                    "div",
                    { style: "text-align:center;font-size:13px;line-height:1.7;color:var(--ink-2)" },
                    h("b", { style: "color:var(--ink)" }, `${f.name}`),
                    " 收藏之后会摆进花房陈列，只能观赏，",
                    h("span", { style: "color:var(--bad,#c0392b)" }, "不能再拿去售卖或上拍了哦"),
                    "。",
                    h("br"),
                    "每种花只能收藏一次，想赚钱就选「采收」。"
                  ),
                  actions: [
                    {
                      label: "我要采收",
                      kind: "gold",
                      onClick: () => {
                        chooseHarvest();
                        sfx.seed();
                        toast(`${f.name}${q.material} ×1 已入包`);
                        endFlow();
                      }
                    },
                    {
                      label: "确定收藏",
                      onClick: () => {
                        chooseKeep();
                        sfx.seed();
                        toast(`${f.name}已摆进花房陈列`, "gold");
                        endFlow();
                      }
                    }
                  ]
                });
              }
            }
          ].filter(Boolean)
        });
      }, 900);
    }
    void rerender;
  }
  function spawnBurst(host, n, colors) {
    if (!host) return;
    for (let i = 0; i < n; i++) {
      const pt = h("span", { class: "pt" });
      const size = 7 + Math.random() * 7;
      pt.style.width = `${size}px`;
      pt.style.height = `${size}px`;
      pt.style.left = `${38 + Math.random() * 24}%`;
      pt.style.top = `${38 + Math.random() * 22}%`;
      pt.style.setProperty("--c", colors[Math.floor(Math.random() * colors.length)]);
      pt.style.setProperty("--dx", `${(Math.random() - 0.5) * 170}px`);
      pt.style.setProperty("--dy", `${-40 - Math.random() * 90}px`);
      pt.style.setProperty("--rr", `${(Math.random() - 0.5) * 420}deg`);
      host.append(pt);
      setTimeout(() => pt.remove(), 820);
    }
  }
  var ICONS = {
    market: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9.5 5.6 4.5h12.8L20 9.5M4.5 9.5V19a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V9.5M3.5 9.5h17M9.5 13.5h5"/></svg>',
    workshop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m14.5 4 5.5 5.5-2.2 2.2L12.3 6.2zM12.6 6.9 4.5 15l4.5 4.5 8.1-8.1M4.5 15 3 21l6-1.5"/></svg>',
    album: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5.5C10 4 7.2 3.5 4 3.5v15c3.2 0 6 .5 8 2 2-1.5 4.8-2 8-2v-15c-3.2 0-6 .5-8 2zM12 5.5v15"/></svg>',
    house: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 20.5V10l8.5-6 8.5 6v10.5M9.5 20.5v-5.5h5v5.5M3.5 20.5h17"/></svg>',
    casket: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3.2 11.4h17.6M5 11.4c0-3.6 3.1-6.3 7-6.3s7 2.7 7 6.3c0 4.7-3.1 8.2-7 8.2s-7-3.5-7-8.2Z"/><circle cx="12" cy="12.6" r="2.3"/></svg>'
  };
  var NAV = [
    { id: "market", label: "花市" },
    { id: "casket", label: "花匣" },
    { id: "workshop", label: "工坊" },
    { id: "album", label: "花谱" },
    { id: "house", label: "花房" }
  ];
  function renderTopbar(el, coinChanged = false) {
    const s = getState();
    el.replaceChildren(
      h(
        "div",
        { class: "brand" },
        h("span", { class: "brand-mark" }, "荚"),
        h("span", { class: "brand-name" }, "种荚花坊")
      ),
      h(
        "div",
        { class: `coin-pill${coinChanged ? " bump" : ""}` },
        h("span", { class: "coin-ico" }, "花"),
        h("b", { class: "coin-num" }, String(s.coin))
      )
    );
  }
  function renderNav(el) {
    const s = getState();
    el.replaceChildren(...NAV.map((n) => h(
      "button",
      {
        class: `nav-btn${s.screen === n.id ? " active" : ""}`,
        onClick: () => {
          if (getState().screen === n.id) return;
          if (flowLocked()) {
            toast("这一荚正开到一半，先把它收完吧");
            sfx.click();
            return;
          }
          sfx.click();
          setState({ screen: n.id });
        }
      },
      h("span", { class: "nav-ico", html: ICONS[n.id] }),
      h("span", null, n.label)
    )));
  }
  function hashStr2(s) {
    let n = 0;
    for (const c of s) n = n * 31 + c.codePointAt(0) >>> 0;
    return n;
  }
  function renderHouse(el) {
    var _a, _b;
    const s = getState();
    const today = flowerOfDay(dayKey());
    const tomo = tomorrowFlower();
    const tip = TIPS[(hashStr2(dayKey()) + s.stats.opened) % TIPS.length];
    const petalKinds = FLOWERS.filter((f) => petalsOf(f.id) > 0).length;
    const craftKinds = Object.values((_a = s.crafts) != null ? _a : {}).reduce((a, b) => a + b, 0);
    const hero = h(
      "div",
      { class: "hero" },
      img(ART.hero, "", "花房封面"),
      h("div", { class: "hero-veil" }),
      h(
        "div",
        { class: "hero-content" },
        h("div", { class: "hero-title" }, "种荚花坊"),
        h("div", { class: "hero-sub" }, `今日开荚 ${s.stats.todayCount} 枚`),
        h(
          "div",
          { class: "bulletin" },
          h("div", null, "今日预告：", h("b", null, today.name), " 正在被客人频频问价"),
          h("div", { class: "tomo" }, `明日预告 · ${tomo.name} 正在悄悄走俏`)
        )
      )
    );
    const statrow = h(
      "div",
      { class: "statrow" },
      statCell(s.pods.filter((p) => !p.peeled).length, "未拆种荚"),
      statCell(petalKinds, "花材品类"),
      statCell(craftKinds, "成品库存")
    );
    const guide = guideCard(s, tip);
    const earned = s.totalEarned;
    const resinDone = resinUnlocked();
    const unlockRow = h(
      "div",
      { class: "unlock-row" },
      h(
        "div",
        { class: "unlock-card" },
        h("div", { class: "u-name" }, "滴胶工坊", resinDone ? h("span", { class: "qchip q-variant" }, "已解锁") : null),
        h("div", { class: "u-desc" }, resinDone ? "变异花蕊可以做成滴胶成品了，去工坊看看。" : "累计赚到花铜币解锁，变异花别急着卖。"),
        h(
          "div",
          { class: "progress" },
          h("div", { class: "progress-bar", style: `width:${Math.min(100, Math.round(earned / RESIN_UNLOCK_EARN * 100))}%` })
        ),
        h("div", { class: "u-desc", style: "margin-top:5px" }, `${Math.min(earned, RESIN_UNLOCK_EARN)} / ${RESIN_UNLOCK_EARN} 币`)
      ),
      h(
        "div",
        { class: "unlock-card" },
        h("div", { class: "u-name" }, "花市大拍", auctionUnlocked() ? h("span", { class: "qchip q-variant" }, "已开放") : h("span", { class: "chip" }, `还差 ${Math.max(0, AUCTION_EARN - earned)} 币`)),
        h("div", { class: "u-desc" }, auctionUnlocked() ? "拍卖行已经开张：每天可以委托一件拍品，三位客人举牌，价高者得。" : `累计赚到 ${AUCTION_EARN} 币开放。传闻拍卖行里，变异花能拍出天价。`),
        h(
          "div",
          { class: "progress" },
          h("div", { class: "progress-bar green", style: `width:${Math.min(100, Math.round(earned / AUCTION_EARN * 100))}%` })
        ),
        h("div", { class: "u-desc", style: "margin-top:5px" }, `${Math.min(earned, AUCTION_EARN)} / ${AUCTION_EARN} 币`),
        auctionUnlocked() ? h("button", {
          class: "btn small gold",
          style: "margin-top:8px",
          onClick: () => {
            sfx.click();
            setState({ screen: "market", ui: __spreadProps(__spreadValues({}, getState().ui), { marketTab: "auction" }) });
          }
        }, "去花市大拍") : null
      )
    );
    const shelfSec = h(
      "div",
      null,
      h("div", { class: "sec" }, "花房陈列", h("span", { class: "sec-aside" }, `收藏的花 ${s.shelf.length} 朵`)),
      s.shelf.length === 0 ? h("div", { class: "card" }, h("div", { class: "empty-hint" }, "还没有收藏的花。", h("br"), "花开的时候选择「收藏」，它就会摆上这里的花架；每种花只能收藏一次，收藏后不能售卖。")) : h(
        "div",
        { class: "shelf" },
        s.shelf.map((fid) => {
          const f = flowerById(fid);
          return h(
            "button",
            {
              class: "frame",
              style: "cursor:pointer;border:none",
              onClick: () => showFlowerModal(f.id)
            },
            img(ART.flowers[fid], "", f.name),
            h("span", null, f.name)
          );
        })
      )
    );
    const decorIds = Object.keys((_b = s.boxDecor) != null ? _b : {});
    const decorSec = h(
      "div",
      null,
      h("div", { class: "sec" }, "限定陈设", h("span", { class: "sec-aside" }, `完好种子换来 ${decorIds.length}/${Object.keys(BOX_DECOR).length} 件`)),
      decorIds.length === 0 ? h("div", { class: "card" }, h(
        "div",
        { class: "empty-hint" },
        "还没有一件限定陈设。",
        h("br"),
        "去花匣开出一颗完好种子，就能换鎏金细颈花器。",
        h("div", { style: "margin-top:9px" }, h("button", {
          class: "btn small ghost",
          onClick: () => {
            sfx.click();
            setState({ screen: "casket", ui: __spreadProps(__spreadValues({}, getState().ui), { casketTab: "open" }) });
          }
        }, "去花匣看看"))
      )) : h(
        "div",
        { class: "decor-row" },
        decorIds.map((id) => {
          const d = BOX_DECOR[id];
          return h("div", { class: "decor-item" }, h("b", null, d.name), h("span", null, d.note));
        })
      )
    );
    const pendParts = [];
    if (s.pending) {
      pendParts.push(h("div", { class: "card", style: "margin-top:12px" }, h("div", { class: "sec" }, "待采收的花", h("span", { class: "sec-aside" }, "还没决定怎么处理")), h("div", { class: "empty-hint" }, "有一朵花开好了，等你决定采收还是收藏。"), h("div", { style: "margin-top:10px" }, h("button", { class: "btn gold", onClick: () => {
        sfx.click();
        setState({ screen: "flow" });
      } }, "去处理这朵花"))));
    }
    const restartSec = h(
      "div",
      { class: "card", style: "margin-top:12px" },
      h("div", { class: "sec" }, "重新开局", h("span", { class: "sec-aside" }, "进度会清空")),
      h("div", { class: "u-desc" }, "刚上手不熟练、把钱花完了？可以清空进度重新开一局，重新体验买荚→开荚→手作→变现。"),
      h("div", { style: "margin-top:10px" }, h("button", {
        class: "btn small ghost",
        onClick: () => {
          sfx.click();
          confirmRestart();
        }
      }, "破产重来 · 重置游戏"))
    );
    el.append(hero, statrow, guide, ...pendParts, h("div", { class: "sec" }, "经营目标"), unlockRow, shelfSec, decorSec, restartSec);
    function statCell(num, label) {
      return h("button", { class: "stat", onClick: openBag }, h("b", null, String(num)), h("span", null, label));
    }
  }
  var LOOP = [
    { id: "buy", label: "买荚", mark: "①" },
    { id: "open", label: "开荚", mark: "②" },
    { id: "craft", label: "手作", mark: "③" },
    { id: "sell", label: "变现", mark: "④" }
  ];
  var goTab = (screen, key, val) => () => setState({ screen, ui: __spreadProps(__spreadValues({}, getState().ui), { [key]: val }) });
  function planNext(s) {
    var _a, _b, _c, _d, _e;
    const unpeeled = s.pods.filter((p) => !p.peeled).length;
    const craftStock = Object.values((_a = s.crafts) != null ? _a : {}).reduce((a, b) => a + b, 0);
    const canCraft = CRAFTS.filter((r) => (r.kind !== "resin" || resinUnlocked()) && craftable(r));
    const petalTotal = FLOWERS.reduce((n, f) => n + petalsOf(f.id), 0);
    const seedTotal = ((_c = (_b = s.seeds) == null ? void 0 : _b.intact) != null ? _c : 0) + ((_e = (_d = s.seeds) == null ? void 0 : _d.broken) != null ? _e : 0);
    const decorLeft = Object.keys(BOX_DECOR).filter((id) => {
      var _a2;
      return !((_a2 = s.boxDecor) == null ? void 0 : _a2[id]);
    }).length;
    const cheapest = Math.min(...PODS.filter((p) => !p.hidden).map((p) => p.price));
    const toMarket = goTab("market", "marketTab", "shop");
    const toSell = goTab("market", "marketTab", "sell");
    const toWorkshop = (tab) => goTab("workshop", "workshopTab", tab);
    const toCasket = (tab) => goTab("casket", "casketTab", tab);
    const alts = [];
    if (canCraft.length) alts.push({ label: `工坊可做 ${canCraft.length} 种`, go: toWorkshop(canCraft[0].kind) });
    if (craftStock) alts.push({ label: `卖 ${craftStock} 件成品`, go: toSell });
    if (seedTotal && decorLeft) alts.push({ label: `花匣 ${seedTotal} 颗种子待兑换`, go: toCasket("trade") });
    if (seedTotal) alts.push({ label: "种一颗种子 · 去浇水", go: () => {
      var _a2, _b2;
      return sowAndStart(((_b2 = (_a2 = s.seeds) == null ? void 0 : _a2.intact) != null ? _b2 : 0) > 0 ? "intact" : "broken");
    } });
    if (boxGiftReady()) alts.push({ label: "领今日花娘馈赠", go: toCasket("open") });
    if (!alts.length && petalTotal) alts.push({ label: `保底卖 ${petalTotal} 份花材`, go: toSell });
    if (s.pods.length) {
      const first = podById(s.pods[0].type);
      return {
        step: "open",
        title: unpeeled ? `剥开这枚${first.name}` : `${first.name}剥好了，去浇水等它发芽`,
        why: unpeeled ? `背包里 ${s.pods.length} 枚种荚，${unpeeled} 枚还没剥壳` : `背包里 ${s.pods.length} 枚种荚排着队，先把它种下去`,
        cta: unpeeled ? "接着经营 · 剥壳" : "接着经营 · 培育",
        go: () => startFlow(s.pods[0].uid),
        alts
      };
    }
    if (canCraft.length) {
      const r = canCraft[0];
      return {
        step: "craft",
        title: `材料齐了，先做「${r.name}」`,
        why: `现在有 ${canCraft.length} 种手作材料齐备。花材直接卖是保底价，做成成品能翻好几倍`,
        cta: "去工坊开工",
        go: toWorkshop(r.kind),
        alts
      };
    }
    if (craftStock) {
      return {
        step: "sell",
        title: `${craftStock} 件成品在背包等出手`,
        why: "压好的花趁新鲜卖，铜币转起来，花坊才活得旺",
        cta: "去集市摆摊",
        go: toSell,
        alts
      };
    }
    if (seedTotal && s.coin < cheapest) {
      return {
        step: "open",
        title: `铜币不够买荚，背包里还有 ${seedTotal} 颗种子`,
        why: "花匣取出的种子和花市买的荚是同一套流程：种下就直接进入第二步——浇水培育，等它绽放。",
        cta: "种进花房 · 去浇水",
        go: () => {
          var _a2, _b2;
          return sowAndStart(((_b2 = (_a2 = s.seeds) == null ? void 0 : _a2.intact) != null ? _b2 : 0) > 0 ? "intact" : "broken");
        },
        alts
      };
    }
    if (seedTotal && decorLeft) {
      return {
        step: "casket",
        title: `手里 ${seedTotal} 颗种子，可以去花匣换好东西`,
        why: "完好种子能换鎏金细颈花器、温室夜灯；摆进花房后每日馈赠还会多给一份",
        cta: "去花匣兑换",
        go: toCasket("trade"),
        alts
      };
    }
    if (s.coin >= cheapest) {
      return {
        step: "buy",
        title: "去花市挑一枚种荚",
        why: `手里 ${s.coin} 币，最便宜的种荚 ${cheapest} 币一枚，外壳线索都写在卡片上`,
        cta: "去花市",
        go: toMarket,
        alts
      };
    }
    if (petalTotal) {
      return {
        step: "sell",
        title: `铜币不够买荚了，先卖 ${petalTotal} 份花材回本`,
        why: "花材保底也能换点零钱，缓过这口气再去开荚",
        cta: "去集市卖花材",
        go: toSell,
        alts
      };
    }
    if (boxFreeLeft() > 0) {
      return {
        step: "casket",
        title: `今天还有 ${boxFreeLeft()} 只免费花匣`,
        why: "开一只取种子，破损种子也能换 25 币——这是眼下最快的回本路子",
        cta: "去花匣开一只",
        go: toCasket("open"),
        alts
      };
    }
    return {
      step: "casket",
      title: "去花匣看看能换什么",
      why: "种子兑换与道具铺里总有能翻本的物件，攒够铜币再回来开荚",
      cta: "去花匣",
      go: toCasket("trade"),
      alts
    };
  }
  function guideCard(s, tip) {
    const plan = planNext(s);
    const cur = LOOP.find((l) => l.id === plan.step);
    return h(
      "div",
      { class: "card guide-card", style: "margin-top:12px" },
      h(
        "div",
        { class: "guide-head" },
        "今天先做什么",
        h("small", null, cur ? `当前环节 · ${cur.mark} ${cur.label}` : "花匣 · 加餐")
      ),
      h(
        "div",
        { class: "gs-ring" },
        LOOP.map((l) => h(
          "span",
          { class: `gs-node${cur && l.id === cur.id ? " cur" : ""}` },
          h("b", null, l.mark),
          l.label
        ))
      ),
      h(
        "div",
        { class: "gs-main" },
        h("div", { class: "gs-title" }, plan.title),
        h("div", { class: "gs-why" }, plan.why)
      ),
      h("div", { class: "tip-line" }, `「${tip}」`),
      h(
        "div",
        { class: "guide-actions" },
        h("button", { class: "btn gold", onClick: () => {
          sfx.click();
          plan.go();
        } }, plan.cta)
      ),
      plan.alts.length ? h(
        "div",
        { class: "gs-alts" },
        h("span", { class: "gs-alt-label" }, "也可以"),
        plan.alts.slice(0, 3).map((a) => h("button", {
          class: "gs-alt",
          onClick: () => {
            sfx.click();
            a.go();
          }
        }, a.label))
      ) : null
    );
  }
  function showFlowerModal(flowerId) {
    const s = getState();
    const f = flowerById(flowerId);
    const q = QUALITY[f.quality];
    if (!s.illustrated[flowerId]) {
      toast("还没开出这朵花，去开几枚种荚吧");
      return;
    }
    sfx.click();
    showModal({
      title: f.name,
      body: h(
        "div",
        { class: "reveal" },
        h("div", { class: `qchip ribbon ${q.cls}` }, q.label + (f.quality === "variant" ? " · 鎏金档案" : "")),
        img(ART.flowers[flowerId], "reveal-img", f.name),
        h("div", { class: "sci" }, f.sci)
      ),
      actions: [{ label: "合上", kind: "ghost" }]
    });
  }
  function openBag() {
    const s = getState();
    sfx.click();
    const box = h("div", null);
    if (s.pods.length > 0) {
      box.append(h("div", { class: "sec" }, "未拆种荚", h("span", { class: "sec-aside" }, `${s.pods.length} 枚`)));
      for (const p of s.pods.slice(0, 8)) {
        const cfg = podById(p.type);
        box.append(h(
          "div",
          { class: "row-card" },
          img(ART.pods[p.type], "rc-img", cfg.name),
          h(
            "div",
            { class: "rc-main" },
            h("div", { class: "rc-name" }, cfg.name, p.peeled ? h("span", { class: "chip" }, "已剥壳") : null),
            h("div", { class: "rc-sub" }, cfg.hint)
          ),
          h(
            "div",
            { class: "rc-side" },
            h("button", { class: "btn small", onClick: () => {
              closeModal();
              startFlow(p.uid);
            } }, "开荚")
          )
        ));
      }
      if (s.pods.length > 8) box.append(h("div", { class: "empty-hint" }, `…还有 ${s.pods.length - 8} 枚，去花房慢慢开`));
    }
    const petalRows = FLOWERS.filter((f) => petalsOf(f.id) > 0);
    if (petalRows.length > 0) {
      box.append(h("div", { class: "sec" }, "花材"));
      for (const f of petalRows) {
        const q = QUALITY[f.quality];
        box.append(h(
          "div",
          { class: "row-card" },
          img(ART.flowers[f.id], "rc-img", f.name),
          h(
            "div",
            { class: "rc-main" },
            h("div", { class: "rc-name" }, f.name, h("span", { class: `qchip ${q.cls}` }, q.label)),
            h("div", { class: "rc-sub" }, `${q.material} · 变卖保底 ${{ normal: 8, rare: 55, variant: 160 }[f.quality]} 币/份`)
          ),
          h("div", { class: "rc-side" }, h("b", { style: "font-family:var(--serif)" }, `×${petalsOf(f.id)}`))
        ));
      }
    }
    const consum = Object.entries(s.consumables).filter(([, n]) => n > 0);
    if (consum.length > 0) {
      box.append(h("div", { class: "sec" }, "耗材"));
      box.append(h(
        "div",
        { style: "display:flex;flex-wrap:wrap;gap:8px" },
        consum.map(([k, n]) => h(
          "span",
          { class: "chip" },
          h("span", { class: "dotc", style: `background:${CONSUMABLE_COLOR[k]}` }),
          `${CONSUMABLES[k].name} ×${n}`
        ))
      ));
    }
    const craftRows = Object.entries(s.crafts).filter(([, n]) => n > 0);
    if (craftRows.length > 0) {
      box.append(h("div", { class: "sec" }, "手作成品"));
      for (const [id, n] of craftRows) {
        const recipe = craftById(id);
        if (!recipe) continue;
        box.append(h(
          "div",
          { class: "row-card" },
          img(recipe.img, "rc-img", recipe.name),
          h(
            "div",
            { class: "rc-main" },
            h("div", { class: "rc-name" }, recipe.name),
            h("div", { class: "rc-sub" }, `建议售价 ${recipe.sell} 币`)
          ),
          h("div", { class: "rc-side" }, h("b", { style: "font-family:var(--serif)" }, `×${n}`))
        ));
      }
    }
    if (!box.childNodes.length) {
      box.append(h("div", { class: "empty-hint" }, "背包空空的，先去花市挑一枚种荚吧。"));
    }
    showModal({
      title: "背包",
      body: box,
      actions: [{ label: "关上背包", kind: "ghost" }]
    });
  }
  var FAIL_MSG = {
    poor: "花铜币不够，先清掉几枚吧",
    soldout: "这一枚今日份额已经没了，明天再来看看",
    empty: "购物车是空的"
  };
  var TABS = [
    { id: "shop", label: "购荚" },
    { id: "supply", label: "耗材" },
    { id: "sell", label: "售卖" },
    { id: "auction", label: "大拍" }
  ];
  var AUCTION_DAY_LIMIT = 1;
  var AUCTION_REROLL_LIMIT = 2;
  var AUCTION_BIDDERS = ["戴礼帽的先生", "花店老板娘", "收藏家小姐", "路过的旅人", "写生的学生", "戴面纱的客人"];
  var auctionUnlocked = () => getState().totalEarned >= AUCTION_EARN;
  function auctionLeft() {
    var _a;
    const s = getState();
    if (s.auction.day !== dayKey()) return AUCTION_DAY_LIMIT;
    return Math.max(0, AUCTION_DAY_LIMIT - ((_a = s.auction.consigned) != null ? _a : 0));
  }
  function auctionBids(lot) {
    const qMul = lot.quality === "variant" ? 1.7 : lot.quality === "rare" ? 1.3 : 1;
    const names = AUCTION_BIDDERS.slice();
    const out = [];
    for (let i = 0; i < 3 && names.length; i++) {
      const name = names.splice(Math.floor(Math.random() * names.length), 1)[0];
      const mult = (2 + Math.random() * 3.2) * qMul;
      out.push({ name, price: Math.max(1, Math.round(lot.base * mult)) });
    }
    return out.sort((a, b) => b.price - a.price);
  }
  function auctionItemList() {
    var _a, _b, _c;
    const s = getState();
    const list = [];
    for (const [id, n] of Object.entries(s.crafts)) {
      if (n <= 0) continue;
      const r = craftById(id);
      if (r) list.push({ kind: "craft", id, name: r.name, quality: (_a = r.quality) != null ? _a : "", base: r.sell, n });
    }
    for (const f of FLOWERS) {
      const n = (_c = (_b = s.petals) == null ? void 0 : _b[f.id]) != null ? _c : 0;
      if (n <= 0) continue;
      list.push({ kind: "petal", id: f.id, name: f.name, quality: f.quality, base: MATERIAL_VALUE[f.quality], n });
    }
    return list;
  }
  function consignAuction(kind, id) {
    const s = getState();
    if (!auctionUnlocked()) return { ok: false, reason: "locked" };
    if (s.auction.lot) return { ok: false, reason: "busy" };
    if (auctionLeft() <= 0) return { ok: false, reason: "daily" };
    const info = auctionItemList().find((x) => x.kind === kind && x.id === id);
    if (!info) return { ok: false, reason: "none" };
    if (kind === "craft") setState((st) => ({ crafts: __spreadProps(__spreadValues({}, st.crafts), { [id]: st.crafts[id] - 1 }) }));
    else setState((st) => ({ petals: __spreadProps(__spreadValues({}, st.petals), { [id]: st.petals[id] - 1 }) }));
    const lot = { kind, id, name: info.name, quality: info.quality, base: info.base };
    setState((st) => {
      var _a;
      return {
        auction: {
          day: dayKey(),
          consigned: (st.auction.day === dayKey() ? (_a = st.auction.consigned) != null ? _a : 0 : 0) + 1,
          lot,
          bids: auctionBids(lot),
          rerolls: 0
        }
      };
    });
    commit();
    return { ok: true, lot };
  }
  function withdrawAuction() {
    const s = getState();
    const lot = s.auction.lot;
    if (!lot) return { ok: false };
    setState((st) => {
      var _a, _b;
      return lot.kind === "craft" ? {
        crafts: __spreadProps(__spreadValues({}, st.crafts), { [lot.id]: ((_a = st.crafts[lot.id]) != null ? _a : 0) + 1 }),
        auction: __spreadProps(__spreadValues({}, st.auction), { lot: null, bids: [] })
      } : {
        petals: __spreadProps(__spreadValues({}, st.petals), { [lot.id]: ((_b = st.petals[lot.id]) != null ? _b : 0) + 1 }),
        auction: __spreadProps(__spreadValues({}, st.auction), { lot: null, bids: [] })
      };
    });
    commit();
    return { ok: true, lot };
  }
  function auctionRerollLeft() {
    var _a;
    const s = getState();
    if (s.auction.day !== dayKey()) return AUCTION_REROLL_LIMIT;
    return Math.max(0, AUCTION_REROLL_LIMIT - ((_a = s.auction.rerolls) != null ? _a : 0));
  }
  function rerollAuction() {
    const s = getState();
    const lot = s.auction.lot;
    if (!lot) return { ok: false };
    if (auctionRerollLeft() <= 0) return { ok: false, reason: "limit" };
    setState((st) => {
      var _a;
      return {
        auction: __spreadProps(__spreadValues({}, st.auction), { lot, bids: auctionBids(lot), rerolls: ((_a = st.auction.rerolls) != null ? _a : 0) + 1 })
      };
    });
    commit();
    return { ok: true };
  }
  function settleAuction(idx) {
    const s = getState();
    const lot = s.auction.lot;
    if (!lot || !s.auction.bids[idx]) return { ok: false };
    const price = s.auction.bids[idx].price;
    setState((st) => ({
      coin: st.coin + price,
      totalEarned: st.totalEarned + price,
      auction: __spreadProps(__spreadValues({}, st.auction), { lot: null, bids: [] })
    }));
    commit();
    return { ok: true, price, lot };
  }
  function renderAuction(el, rerender) {
    var _a, _b;
    const s = getState();
    el.append(h(
      "div",
      { class: "scene-card" },
      img(ART.scenes.market, "", "花市大拍"),
      h("div", { class: "sc-veil" }),
      h("div", { class: "sc-label" }, "花市大拍"),
      h("div", { class: "sc-sub" }, "把压箱底的东西交给客人举牌")
    ));
    if (!auctionUnlocked()) {
      const pct = Math.min(100, Math.round(s.totalEarned / AUCTION_EARN * 100));
      el.append(h(
        "div",
        { class: "card" },
        h("div", { class: "u-name" }, "花市大拍", h("span", { class: "chip" }, "未开放")),
        h("div", { class: "u-desc" }, `累计赚到 ${AUCTION_EARN} 币开放。拍卖行里只收一件拍品，出价是平时的好几倍。`),
        h("div", { class: "progress" }, h("div", { class: "progress-bar green", style: `width:${pct}%` })),
        h("div", { class: "u-desc", style: "margin-top:5px" }, `${Math.min(s.totalEarned, AUCTION_EARN)} / ${AUCTION_EARN} 币`)
      ));
      return;
    }
    const lot = s.auction.lot;
    if (lot) {
      const cover = lot.kind === "craft" ? (_a = craftById(lot.id)) == null ? void 0 : _a.img : ART.flowers[lot.id];
      const q = lot.quality ? QUALITY[lot.quality] : null;
      el.append(h("div", { class: "sec" }, "今日拍品", h("span", { class: "sec-aside" }, `底价 ${lot.base} 币`)));
      el.append(h(
        "div",
        { class: "row-card" },
        img(cover, "rc-img", lot.name),
        h(
          "div",
          { class: "rc-main" },
          h("div", { class: "rc-name" }, lot.name, q ? h("span", { class: `qchip ${q.cls}` }, q.label) : null),
          h("div", { class: "rc-sub" }, lot.kind === "craft" ? "手作成品 · 已交给拍卖行" : `${q ? q.material : "花材"} · 已交给拍卖行`)
        )
      ));
      el.append(h("div", { class: "sec" }, "客人出价", h("span", { class: "sec-aside" }, "价高者得")));
      s.auction.bids.forEach((b, i) => {
        el.append(h(
          "div",
          { class: "row-card" },
          h(
            "div",
            { class: "rc-main" },
            h("div", { class: "rc-name" }, b.name, i === 0 ? h("span", { class: "chip" }, "当前最高") : null),
            h("div", { class: "rc-sub" }, i === 0 ? "就等主人点头了" : "还在举牌")
          ),
          h(
            "div",
            { class: "rc-side", style: "display:flex;gap:6px;align-items:center" },
            h("div", { class: "coin-inline" }, h("span", { class: "coin-ico" }, "花"), `+${b.price}`),
            h("button", {
              class: `btn small${i === 0 ? " gold" : " ghost"}`,
              onClick: () => {
                const r = settleAuction(i);
                if (!r.ok) return;
                sfx.coin();
                toast(`${lot.name}成交，+${r.price} 币`, "gold");
                rerender();
              }
            }, "成交")
          )
        ));
      });
      el.append(h(
        "div",
        { class: "guide-banner", style: "margin-top:12px" },
        "不满意可以换一批举牌的客人，但新价可能更高也可能更低；也可以撤拍退回背包。每天最多换 " + AUCTION_REROLL_LIMIT + " 次。",
        h(
          "div",
          { style: "display:flex;gap:8px;margin-top:8px" },
          h("button", {
            class: `btn small${auctionRerollLeft() > 0 ? "" : " disabled"}`,
            onClick: () => {
              const rr = rerollAuction();
              if (!rr.ok) {
                toast(rr.reason === "limit" ? "今天已经换过两批买家了，就在这批里挑一个吧" : "这件拍品暂时不能换买家", "bad");
                return;
              }
              sfx.click();
              toast("换了一批举牌的客人", "info");
              rerender();
            }
          }, `换个买家（剩 ${auctionRerollLeft()}）`),
          h("button", {
            class: "btn small ghost",
            onClick: () => {
              const r = withdrawAuction();
              if (!r.ok) return;
              sfx.click();
              toast(`${lot.name}已撤拍，退回背包`, "info");
              rerender();
            }
          }, "撤拍退回")
        )
      ));
      return;
    }
    const left = auctionLeft();
    el.append(h("div", { class: "sec" }, "委托拍品", h("span", { class: "sec-aside" }, `今日还可委托 ${left} 件`)));
    if (left <= 0) {
      el.append(h("div", { class: "card" }, h("div", { class: "empty-hint" }, "今天的拍品名额用完了，明天再来吧。", h("br"), "每天只能委托一件，选最值钱的那件。")));
      return;
    }
    const items = auctionItemList();
    if (!items.length) {
      el.append(h("div", { class: "card" }, h("div", { class: "empty-hint" }, "还没有可以拍卖的东西。", h("br"), "做好的押花、装饰画、滴胶，或者采收到的花材都能上拍。")));
      return;
    }
    for (const it of items) {
      const q = it.quality ? QUALITY[it.quality] : null;
      const cover = it.kind === "craft" ? (_b = craftById(it.id)) == null ? void 0 : _b.img : ART.flowers[it.id];
      el.append(h(
        "div",
        { class: "row-card" },
        img(cover, "rc-img", it.name),
        h(
          "div",
          { class: "rc-main" },
          h("div", { class: "rc-name" }, it.name, q ? h("span", { class: `qchip ${q.cls}` }, q.label) : null, h("span", { class: "chip" }, `×${it.n}`)),
          h("div", { class: "rc-sub" }, `平时只能卖 ${it.base} 币，上拍能多卖好几倍`)
        ),
        h(
          "div",
          { class: "rc-side" },
          h("button", {
            class: "btn small gold",
            onClick: () => {
              const r = consignAuction(it.kind, it.id);
              if (!r.ok) {
                toast(r.reason === "daily" ? "今天的委托名额用完了" : "这件东西拍不了", "bad");
                return;
              }
              sfx.click();
              toast(`${it.name}已交给拍卖行，客人正在举牌`, "gold");
              rerender();
            }
          }, "委托拍卖")
        )
      ));
    }
    el.append(h(
      "div",
      { class: "guide-banner", style: "margin-top:12px" },
      "花房陈列里收藏的花不参与拍卖，它们只负责好看。"
    ));
  }
  var cart = [];
  var ticks = [];
  function clearTicks() {
    ticks.forEach(clearInterval);
    ticks = [];
  }
  function renderMarket(el, rerender) {
    clearTicks();
    const s = getState();
    const tab = s.ui.marketTab;
    el.append(h(
      "div",
      { class: "tabs" },
      TABS.map((t) => h("button", {
        class: `tab${tab === t.id ? " active" : ""}`,
        onClick: () => {
          sfx.click();
          setState({ ui: __spreadProps(__spreadValues({}, getState().ui), { marketTab: t.id }) });
        }
      }, t.label))
    ));
    if (tab === "shop") renderShop(el, rerender);
    else if (tab === "supply") renderSupply(el, rerender);
    else if (tab === "auction") renderAuction(el, rerender);
    else renderSell(el);
  }
  function renderShop(el, rerender) {
    const s = getState();
    el.append(h(
      "div",
      { class: "guide-banner" },
      h("b", null, "先做这件事："),
      "挑一枚你想开的种荚。价格和线索都写在卡片上，入库后可以直接开，30 秒内也能原价回购。"
    ));
    const free = !s.stats.refreshUsed;
    el.append(h(
      "div",
      { class: "market-tools" },
      h("span", null, "今日货源价有浮动，便宜时可以囤荚"),
      h("button", {
        class: `btn small ghost${!free && s.coin < REFRESH_COST ? " disabled" : ""}`,
        onClick: () => {
          const r = refreshSupply();
          if (!r.ok) {
            toast("花铜币不够啦", "bad");
            return;
          }
          sfx.click();
          toast(r.free ? "换了一批新货源（今日免费）" : `换了一批新货源，-${REFRESH_COST} 币`);
        }
      }, `换一批货源 · ${free ? "免费" : `${REFRESH_COST} 币`}`)
    ));
    if (goldenGuestHere()) {
      el.append(h(
        "div",
        { class: "guest-banner" },
        h("span", { class: "gb-mark" }, "✦"),
        h("div", null, "鎏金来客", h("div", { class: "gb-sub" }, "黄金灵荚今日驾到，必出稀有以上，错过要等下一阵子。"))
      ));
    }
    if (!timelessUnlocked()) {
      const need = timelessNeed();
      el.append(h(
        "div",
        { class: "locked-card" },
        h("div", { class: "lk-title" }, "时间古荚 · 尚未苏醒"),
        h("div", { class: "lk-sub" }, `累计开荚满 50 枚后上架，每日只有 1 枚。还差 ${need} 枚。`),
        h("div", { class: "lk-bar" }, h("i", { style: `width:${Math.min(100, (50 - need) * 2)}%` }))
      ));
    }
    for (const cfg of availablePods(s)) {
      const now = priceOf(cfg.id);
      const afford = s.coin >= now;
      const left = podStockLeft(cfg);
      const hidden = !!cfg.hidden;
      el.append(h(
        "div",
        { class: `pod-card${hidden ? " guest" : ""}` },
        img(ART.pods[cfg.id], "pod-thumb", cfg.name),
        h(
          "div",
          { class: "pod-info" },
          h(
            "div",
            { class: "pod-name" },
            cfg.name,
            h("span", { class: `tag${hidden ? " gold" : ""}` }, cfg.tag),
            hidden && left !== Infinity ? h("span", { class: "stock" }, `今日剩 ${left} 枚`) : null
          ),
          h("div", { class: "pod-hint" }, cfg.hint),
          h(
            "div",
            { class: "price-row" },
            h("span", { class: "now" }, h("span", { class: "coin-ico" }, "花"), String(now)),
            now !== cfg.price ? h("span", { class: "base" }, `常价 ${cfg.price}`) : null
          ),
          h(
            "div",
            { class: "pod-actions" },
            h("button", {
              class: `btn small${afford ? "" : " disabled"}`,
              onClick: () => buy(cfg.id, 1)
            }, "立即买下"),
            h("button", {
              class: "btn small ghost",
              disabled: left !== Infinity && left <= cart.filter((t) => t === cfg.id).length,
              onClick: () => {
                if (left !== Infinity && left <= cart.filter((t) => t === cfg.id).length) {
                  toast("今日份额已经进购物车啦");
                  return;
                }
                cart.push(cfg.id);
                sfx.click();
                toast(`已加入购物车（${cart.length} 枚）`);
              }
            }, "加入购物车")
          )
        )
      ));
    }
    const recent = recentBuyablePods();
    if (recent.length > 0) {
      const strip = h("div", { class: "refund-strip" }, h("div", { class: "rs-title" }, "刚刚购入 · 30 秒内可回购"));
      for (const p of recent) {
        const cfg = podById(p.type);
        const secEl = h("span", { class: "rs-sec" }, `剩 ${leftSec(p)}s`);
        const btn = h("button", {
          class: "btn small gold",
          onClick: () => {
            const r = refundPod(p.uid);
            if (!r.ok) {
              toast("超过回购时限了", "bad");
              return;
            }
            sfx.coin();
            toast(`已回购${cfg.name}，+${r.amount} 币`, "gold");
          }
        }, `回购 +${p.boughtPrice}`);
        strip.append(h(
          "div",
          { class: "refund-row", dataset: { uid: p.uid } },
          h("span", { class: "rs-name" }, cfg.name),
          secEl,
          btn
        ));
      }
      el.append(strip);
      ticks.push(setInterval(() => {
        const alive = recentBuyablePods();
        let changed = false;
        el.querySelectorAll(".refund-row").forEach((row) => {
          const uid = row.dataset.uid;
          const pod = getState().pods.find((x) => x.uid === uid);
          if (!pod || Date.now() - pod.boughtAt > REFUND_WINDOW_MS) {
            changed = true;
            return;
          }
          const sec = row.querySelector(".rs-sec");
          if (sec) sec.textContent = `剩 ${leftSec(pod)}s`;
        });
        if (changed || alive.length === 0) rerender();
      }, 1e3));
    }
    if (cart.length > 0) {
      const total = cart.reduce((n, t) => n + priceOf(t), 0);
      el.append(h(
        "div",
        { class: "cartbar" },
        h("div", { class: "cb-info" }, "今日购物车 · ", h("b", null, `${cart.length} 枚`), h("div", null, `合计 ${total} 币`)),
        h("button", { class: "btn clear", onClick: () => {
          cart = [];
          rerender();
        } }, "清空"),
        h("button", { class: "btn gold", onClick: () => settle(rerender) }, "去结算")
      ));
    }
    function buy(type, n) {
      var _a;
      const r = buyPods(Array(n).fill(type));
      if (!r.ok) {
        toast((_a = FAIL_MSG[r.reason]) != null ? _a : "买不了这枚，再试一次", "bad");
        return;
      }
      sfx.coin();
      const cfg = podById(type);
      toast(`购入 ${cfg.name}，-${r.total} 币。快去开荚吧！`, "gold");
      rerender();
    }
    function settle(rr) {
      var _a;
      if (cart.length === 0) return;
      const r = buyPods(cart);
      if (!r.ok) {
        toast((_a = FAIL_MSG[r.reason]) != null ? _a : "结算没成功，再试一次", "bad");
        return;
      }
      sfx.coin();
      cart = [];
      const extra = r.skipped ? `（另有 ${r.skipped} 枚今日份额已售罄）` : "";
      toast(`结算成功，购入 ${r.bought.length} 枚种荚，-${r.total} 币${extra}`, "gold");
      rr();
    }
    function leftSec(pod) {
      return Math.max(0, Math.ceil((REFUND_WINDOW_MS - (Date.now() - pod.boughtAt)) / 1e3));
    }
  }
  function renderSupply(el, rerender) {
    var _a;
    const s = getState();
    el.append(h(
      "div",
      { class: "scene-card" },
      img(ART.crafts.resinCombo, "", "滴胶手作"),
      h("div", { class: "sc-veil" }),
      h("div", { class: "sc-label" }, "耗材小铺"),
      h("div", { class: "sc-sub" }, "工坊手作，随时补货")
    ));
    el.append(h(
      "div",
      { class: "guide-banner", style: "margin-top:10px" },
      "押花要",
      h("b", null, "卡纸"),
      "，装饰画要",
      h("b", null, "卡纸+相框"),
      "，滴胶要",
      h("b", null, "滴胶+丝带"),
      "。开工前看一眼库存，别让花材等急了。"
    ));
    for (const [id, c] of Object.entries(CONSUMABLES)) {
      const afford = s.coin >= c.price;
      el.append(h(
        "div",
        { class: "row-card" },
        h("span", {
          style: `width:44px;height:44px;border-radius:12px;flex:none;display:grid;place-items:center;background:${CONSUMABLE_COLOR[id]}22;border:1px solid ${CONSUMABLE_COLOR[id]}55;color:${CONSUMABLE_COLOR[id]};font-weight:700;font-size:12px`
        }, c.name.slice(0, 1)),
        h(
          "div",
          { class: "rc-main" },
          h("div", { class: "rc-name" }, c.name, h("span", { class: "chip" }, `已有 ×${(_a = s.consumables[id]) != null ? _a : 0}`)),
          h("div", { class: "rc-sub" }, c.desc)
        ),
        h(
          "div",
          { class: "rc-side" },
          h(
            "div",
            { class: "coin-inline", style: "justify-content:flex-end;margin-bottom:6px" },
            h("span", { class: "coin-ico" }, "花"),
            String(c.price)
          ),
          h("button", {
            class: `btn small${afford ? "" : " disabled"}`,
            onClick: () => {
              const r = buyConsumable(id);
              if (!r.ok) {
                toast("花铜币不够啦", "bad");
                return;
              }
              sfx.coin();
              toast(`买下一份${c.name}`);
              rerender();
            }
          }, "买下")
        )
      ));
    }
  }
  function renderSell(el) {
    const s = getState();
    el.append(h(
      "div",
      { class: "scene-card" },
      img(ART.scenes.market, "", "集市摊位"),
      h("div", { class: "sc-veil" }),
      h("div", { class: "sc-label" }, "集市摊位"),
      h("div", { class: "sc-sub" }, "把成品换成交给客人")
    ));
    el.append(h("div", { class: "sec" }, "手作成品", h("span", { class: "sec-aside" }, "按建议价售出")));
    const craftRows = Object.entries(s.crafts).filter(([, n]) => n > 0);
    if (craftRows.length === 0) {
      el.append(h("div", { class: "card" }, h("div", { class: "empty-hint" }, "摊位上还没有成品。", h("br"), "去工坊把花材做成押花和滴胶吧。")));
    } else {
      for (const [id, n] of craftRows) {
        const recipe = craftById(id);
        if (!recipe) continue;
        el.append(h(
          "div",
          { class: "row-card" },
          img(recipe.img, "rc-img", recipe.name),
          h(
            "div",
            { class: "rc-main" },
            h("div", { class: "rc-name" }, recipe.name, h("span", { class: "chip" }, `×${n}`)),
            h("div", { class: "rc-sub" }, "客人很喜欢这类手作")
          ),
          h(
            "div",
            { class: "rc-side" },
            h(
              "div",
              { class: "coin-inline", style: "justify-content:flex-end;margin-bottom:6px" },
              h("span", { class: "coin-ico" }, "花"),
              `+${recipe.sell}`
            ),
            h("button", {
              class: "btn small gold",
              onClick: () => {
                const r = sellCraft(id);
                if (!r.ok) return;
                sfx.coin();
                toast(`卖出${recipe.name}，+${r.amount} 币`, "gold");
              }
            }, "售出")
          )
        ));
      }
    }
    el.append(h("div", { class: "sec" }, "花材保底", h("span", { class: "sec-aside" }, "不做手作也能换币")));
    const petalRows = FLOWERS.filter((f) => {
      var _a, _b;
      return ((_b = (_a = s.petals) == null ? void 0 : _a[f.id]) != null ? _b : 0) > 0;
    });
    if (petalRows.length === 0) {
      el.append(h("div", { class: "card" }, h("div", { class: "empty-hint" }, "还没有花材。采收开出的花就能拿到花瓣。")));
    } else {
      for (const f of petalRows) {
        const q = QUALITY[f.quality];
        const n = s.petals[f.id];
        const unit = MATERIAL_VALUE[f.quality];
        el.append(h(
          "div",
          { class: "row-card" },
          img(ART.flowers[f.id], "rc-img", f.name),
          h(
            "div",
            { class: "rc-main" },
            h("div", { class: "rc-name" }, f.name, h("span", { class: `qchip ${q.cls}` }, q.label)),
            h("div", { class: "rc-sub" }, `${q.material} ×${n} · 保底 ${unit} 币/份`)
          ),
          h(
            "div",
            { class: "rc-side", style: "display:flex;gap:6px" },
            h("button", {
              class: "btn small ghost",
              onClick: () => doSellPetal(f.id, 1)
            }, "售出 1"),
            n > 1 ? h("button", {
              class: "btn small gold",
              onClick: () => doSellPetal(f.id, n)
            }, `全部 +${n * unit}`) : null
          )
        ));
      }
      el.append(h(
        "div",
        { class: "guide-banner", style: "margin-top:12px" },
        "花材直接变卖是保底价，做成成品能卖出好几倍——花娘建议先做手作。"
      ));
    }
    function doSellPetal(fid, cnt) {
      const r = sellPetals(fid, cnt);
      if (!r.ok) return;
      sfx.coin();
      const f = flowerById(fid);
      toast(`卖出 ${f.name}${QUALITY[f.quality].material} ×${r.cnt}，+${r.amount} 币`, "gold");
    }
  }
  var TABS2 = [
    { id: "press", label: "押花" },
    { id: "paint", label: "装饰画" },
    { id: "resin", label: "滴胶" }
  ];
  function renderWorkshop(el) {
    const s = getState();
    const tab = s.ui.workshopTab;
    el.append(
      h(
        "div",
        { class: "scene-card" },
        img(ART.scenes.workshop, "", "工坊一角"),
        h("div", { class: "sc-veil" }),
        h("div", { class: "sc-label" }, "工坊 · 手作时间"),
        h("div", { class: "sc-sub" }, "把花材做成更值钱的成品")
      ),
      h("div", { class: "album-summary" }, materialChips(s))
    );
    el.append(h(
      "div",
      { class: "tabs" },
      TABS2.map((t) => h("button", {
        class: `tab${tab === t.id ? " active" : ""}`,
        onClick: () => {
          sfx.click();
          setState({ ui: __spreadProps(__spreadValues({}, getState().ui), { workshopTab: t.id }) });
        }
      }, t.label))
    ));
    if (tab === "resin" && !resinUnlocked()) {
      renderLock(el);
      return;
    }
    const recipes = CRAFTS.filter((r) => tab === "press" ? r.kind === "press" : tab === "paint" ? r.kind === "paint" : r.kind === "resin");
    if (recipes.length === 0) {
      el.append(h("div", { class: "card" }, h("div", { class: "empty-hint" }, "这里的配方还在拟定中。")));
      return;
    }
    for (const recipe of recipes) el.append(recipeCard(recipe));
  }
  function materialChips(s) {
    var _a;
    const nTotal = FLOWERS.filter((f) => f.quality === "normal").reduce((a, f) => a + petalsOf(f.id), 0);
    const rTotal = FLOWERS.filter((f) => f.quality === "rare").reduce((a, f) => a + petalsOf(f.id), 0);
    const vTotal = FLOWERS.filter((f) => f.quality === "variant").reduce((a, f) => a + petalsOf(f.id), 0);
    const chips = [
      h("span", { class: "chip" }, h("span", { class: "dotc", style: "background:var(--green)" }), `普通花瓣 ×${nTotal}`),
      h("span", { class: "chip" }, h("span", { class: "dotc", style: "background:var(--blue)" }), `稀有花瓣 ×${rTotal}`),
      h("span", { class: "chip" }, h("span", { class: "dotc", style: "background:var(--purple)" }), `变异花蕊 ×${vTotal}`)
    ];
    for (const [k, c] of Object.entries(CONSUMABLES)) {
      chips.push(h(
        "span",
        { class: "chip" },
        h("span", { class: "dotc", style: `background:${CONSUMABLE_COLOR[k]}` }),
        `${c.name} ×${(_a = s.consumables[k]) != null ? _a : 0}`
      ));
    }
    return chips;
  }
  function recipeCard(recipe) {
    const s = getState();
    const needs = craftNeeds(recipe);
    const can = craftable(recipe);
    const flower = recipe.flowerId ? FLOWERS.find((f) => f.id === recipe.flowerId) : null;
    return h(
      "div",
      { class: "recipe-card" },
      h(
        "div",
        { class: "recipe-thumb" },
        img(recipe.img, "", recipe.name),
        recipe.baseImg ? img(recipe.baseImg, "base-thumb", "押花底样") : null
      ),
      h(
        "div",
        { class: "recipe-info" },
        h(
          "div",
          { class: "recipe-name" },
          recipe.name,
          flower ? h("span", { class: `qchip ${QUALITY[flower.quality].cls}` }, QUALITY[flower.quality].label) : null
        ),
        h(
          "div",
          { class: "needs" },
          needs.map((n) => h("span", { class: `need ${n.ok ? "ok" : "no"}` }, `${n.ok ? "✓" : "✗"} ${n.label}`))
        ),
        h(
          "div",
          { class: "recipe-foot" },
          h("span", { class: "sell-hint" }, "建议售价 ", h("span", { class: "coin-inline" }, h("span", { class: "coin-ico" }, "花"), String(recipe.sell))),
          h("button", {
            class: `btn small${can ? "" : " disabled"}`,
            onClick: () => tryCraft(recipe)
          }, "制作")
        )
      )
    );
  }
  function tryCraft(recipe) {
    if (!craftable(recipe)) {
      toast("材料或工坊费不足，看看还缺什么");
      return;
    }
    sfx.click();
    showModal({
      title: "开始手作",
      body: h(
        "div",
        null,
        h(
          "div",
          { style: "display:flex;gap:12px;align-items:center" },
          img(recipe.img, "rc-img", recipe.name),
          h(
            "div",
            null,
            h("div", { class: "rc-name" }, recipe.name),
            h("div", { class: "rc-sub" }, `工坊费 ${recipe.fee} 币 · 建议售价 ${recipe.sell} 币`)
          )
        ),
        h(
          "div",
          { class: "needs", style: "margin-top:10px" },
          craftNeeds(recipe).map((n) => h("span", { class: `need ${n.ok ? "ok" : "no"}` }, `${n.ok ? "✓" : "✗"} ${n.label}`))
        )
      ),
      actions: [
        { label: "再想想", kind: "ghost" },
        {
          label: "开始制作",
          onClick: () => {
            const r = doCraft(recipe.id);
            if (!r.ok) {
              toast("材料或工坊费不足", "bad");
              return;
            }
            sfx.craft();
            showModal({
              title: "手作完成",
              body: h(
                "div",
                { class: "reveal" },
                img(recipe.img, "reveal-img", recipe.name),
                h("div", { class: "r-name" }, recipe.name),
                h("div", { class: "sci" }, `做好了！建议售价 ${recipe.sell} 币，已放进背包，去集市摆上摊位吧。`)
              ),
              actions: [{ label: "收好", kind: "gold" }]
            });
          }
        }
      ]
    });
  }
  function renderLock(el) {
    const s = getState();
    const earned = s.totalEarned;
    el.append(h(
      "div",
      { class: "lock-card" },
      h("div", { class: "lk-ico" }, "封"),
      h("div", { class: "lk-title" }, "滴胶工坊 · 尚未解锁"),
      h("div", { class: "lk-desc" }, "等花坊攒下口碑（累计赚到花铜币），就能封存变异花的美丽。"),
      h(
        "div",
        { class: "progress", style: "max-width:220px;margin:12px auto 6px" },
        h("div", { class: "progress-bar", style: `width:${Math.min(100, Math.round(earned / RESIN_UNLOCK_EARN * 100))}%` })
      ),
      h("div", { class: "lk-desc" }, `${Math.min(earned, RESIN_UNLOCK_EARN)} / ${RESIN_UNLOCK_EARN} 币`)
    ));
    const vTotal = FLOWERS.filter((f) => f.quality === "variant").reduce((a, f) => a + petalsOf(f.id), 0);
    if (vTotal > 0) {
      el.append(h(
        "div",
        { class: "guide-banner", style: "margin-top:12px" },
        `你已经存了 ${vTotal} 份变异花蕊——解锁后第一件事就是把它做成滴胶！`
      ));
    }
  }
  function renderAlbum(el) {
    const s = getState();
    const unlocked = FLOWERS.filter((f) => s.illustrated[f.id]);
    const pct = Math.round(unlocked.length / FLOWERS.length * 100);
    el.append(h(
      "div",
      { class: "card", style: "text-align:center;margin-top:6px" },
      h(
        "div",
        { style: "font-family:var(--serif);font-weight:700;font-size:26px" },
        `${unlocked.length}`,
        h("span", { style: "font-size:14px;color:var(--ink-2)" }, ` / ${FLOWERS.length} 种`)
      ),
      h(
        "div",
        { class: "progress", style: "max-width:200px;margin:10px auto 4px" },
        h("div", { class: "progress-bar", style: `width:${pct}%` })
      ),
      h("div", { style: "font-size:11.5px;color:var(--ink-2);margin-top:6px" }, `收集进度 ${pct}% · 开出的花会自动记入花谱`),
      h(
        "div",
        { class: "album-summary", style: "justify-content:center" },
        ["normal", "rare", "variant"].map((q) => {
          const pool = FLOWERS.filter((f) => f.quality === q);
          const got = pool.filter((f) => s.illustrated[f.id]).length;
          return h(
            "span",
            { class: "chip" },
            h("span", { class: "dotc", style: `background:${q === "normal" ? "var(--green)" : q === "rare" ? "var(--blue)" : "var(--purple)"}` }),
            `${QUALITY[q].label}线 ${got}/${pool.length}`
          );
        })
      )
    ));
    el.append(h(
      "div",
      { class: "album-grid" },
      FLOWERS.map((f) => {
        const q = QUALITY[f.quality];
        const got = !!s.illustrated[f.id];
        return h(
          "button",
          {
            class: `al-card${got ? "" : " locked"}${f.quality === "variant" ? " variant" : ""}`,
            onClick: () => {
              if (!got) {
                toast("还没开出这朵花，去开几枚种荚吧");
                return;
              }
              showFlowerModal(f.id);
            }
          },
          h(
            "div",
            { class: got ? "" : "qmark" },
            img(ART.flowers[f.id], "", got ? f.name : "未解锁")
          ),
          h("div", { class: "al-name" }, got ? f.name : "？？？"),
          got ? h("span", { class: `qchip ${q.cls}` }, q.label) : null
        );
      })
    ));
    el.append(h(
      "div",
      { class: "guide-banner", style: "margin-top:14px" },
      "变异条带鎏金边——集齐四朵变异花，是花娘最大的心愿。"
    ));
  }
  var session2 = null;
  var storyShown = false;
  var TABS3 = [
    { id: "open", label: "开匣" },
    { id: "trade", label: "种子兑换" },
    { id: "shop", label: "道具铺" }
  ];
  function newSession() {
    return { angle: 0, props: [], phase: "aim", result: null, used: [], cost: 0 };
  }
  var hasProp = (id) => !!session2 && session2.props.includes(id);
  function spriteStyle(url, rows, cols, idx) {
    const col = idx % cols;
    const row = Math.floor(idx / cols);
    return {
      "background-image": `url(${url})`,
      "background-size": `${cols * 100}% ${rows * 100}%`,
      "background-position": `${cols > 1 ? col * 100 / (cols - 1) : 0}% ${rows > 1 ? row * 100 / (rows - 1) : 0}%`
    };
  }
  var propStyle = (id) => spriteStyle(ART.props.url, ART.props.rows, ART.props.cols, BOX_PROPS[id].sprite);
  var cssOf = (map) => Object.entries(map).map(([k, v]) => `${k}:${v}`).join(";");
  var toTrade = () => setState({ ui: __spreadProps(__spreadValues({}, getState().ui), { casketTab: "trade" }) });
  function nextMilestone(s) {
    var _a, _b, _c, _d;
    const opened = (_b = (_a = s.boxStats) == null ? void 0 : _a.opened) != null ? _b : 0;
    const m = BOX_MILESTONES.find((x) => opened < x.at);
    if (!m) return null;
    const prev = (_d = (_c = BOX_MILESTONES[BOX_MILESTONES.indexOf(m) - 1]) == null ? void 0 : _c.at) != null ? _d : 0;
    const span = Math.max(1, m.at - prev);
    return {
      left: m.at - opened,
      pct: Math.min(100, Math.round((opened - prev) / span * 100)),
      note: `${m.note.replace(/^开匣满 \d+ 只：/, "")}（累计 ${m.at} 只）`
    };
  }
  function decorGoal(s) {
    var _a, _b, _c, _d, _e, _f, _g;
    for (const [id, d] of Object.entries(BOX_DECOR)) {
      if ((_a = s.boxDecor) == null ? void 0 : _a[id]) continue;
      const li = Math.max(0, ((_b = d.need.intact) != null ? _b : 0) - ((_c = s.seeds.intact) != null ? _c : 0));
      const lb = Math.max(0, ((_d = d.need.broken) != null ? _d : 0) - ((_e = s.seeds.broken) != null ? _e : 0));
      const need = ((_f = d.need.intact) != null ? _f : 0) + ((_g = d.need.broken) != null ? _g : 0);
      const got = need - li - lb;
      return {
        name: d.name,
        lack: [li ? `完好×${li}` : null, lb ? `破损×${lb}` : null].filter(Boolean).join("、"),
        pct: need ? Math.min(100, Math.round(got / need * 100)) : 100
      };
    }
    return null;
  }
  function renderCasket(el, rerender) {
    var _a, _b, _c;
    const s = getState();
    const tab = (_a = s.ui.casketTab) != null ? _a : "open";
    if (!podOpening) el.append(h(
      "div",
      { class: "scene-card box-scene" },
      img(ART.box.closed, "", "花匣"),
      h("div", { class: "sc-veil" }),
      h("div", { class: "sc-label" }, "花匣 · 种子"),
      h("div", { class: "sc-sub" }, "瓣壳柔软，内里带着薄锐的棱片")
    ));
    if (!podOpening) el.append(h(
      "div",
      { class: "tabs" },
      TABS3.map((t) => h("button", {
        class: `tab${tab === t.id ? " active" : ""}`,
        onClick: () => {
          var _a2;
          if (((_a2 = getState().ui.casketTab) != null ? _a2 : "open") === t.id) return;
          sfx.click();
          setState({ ui: __spreadProps(__spreadValues({}, getState().ui), { casketTab: t.id }) });
          rerender();
        }
      }, t.label))
    ));
    if (tab === "open") renderOpen(el, rerender);
    else if (tab === "trade") renderTrade(el, rerender);
    else renderShop2(el, rerender);
    if (!podOpening) el.append(h("div", { class: "box-foot" }, BOX_FOOT_NOTE));
    if (tab === "open" && !podOpening && !storyShown && ((_c = (_b = s.boxStats) == null ? void 0 : _b.opened) != null ? _c : 0) === 0) {
      storyShown = true;
      showStory();
    }
  }
  function showStory() {
    showModal({
      title: "打开一只花匣",
      body: h(
        "div",
        { class: "box-story" },
        img(ART.box.closed, "story-img", "花匣"),
        h("div", { class: "story-text" }, BOX_STORY)
      ),
      actions: [{ label: "我知道怎么开了" }]
    });
  }
  function renderOpen(el, rerender) {
    var _a, _b, _c, _d, _e, _f;
    const s = getState();
    if (podOpening) {
      renderPodOpen(el, rerender);
      return;
    }
    if (!session2) session2 = newSession();
    const peelQueue = s.pods.filter((p) => !p.peeled);
    const growQueue = s.pods.filter((p) => p.peeled);
    const podBusy = !!session && flowLocked();
    if (peelQueue.length && !skipPodOnce && !podBusy) {
      const uid0 = peelQueue[0].uid;
      const pod0 = openPod(uid0);
      if (pod0) {
        warmFlow(pod0.type);
        clearTimer();
        session = {
          uid: uid0,
          type: pod0.type,
          phase: pod0.peeled ? "ready" : "peel",
          damaged: pod0.damaged === true,
          n: 0,
          watering: false,
          result: null,
          modalShown: false
        };
        podOpening = uid0;
        session2 = newSession();
        renderPodOpen(el, rerender);
        return;
      }
    }
    if (peelQueue.length && !podBusy) {
      const p0 = peelQueue[0];
      const c0 = podById(p0.type);
      el.append(h(
        "div",
        { class: "gift-card" },
        h(
          "div",
          { class: "gc-text" },
          "背包里还有",
          h("b", null, `${peelQueue.length} 枚种荚没剥壳`),
          h("div", { class: "gc-sub" }, `下一枚：${c0 ? c0.name : "种荚"}。开荚和开匣是同一套手法，就在这个页面开，不用回花房绕一圈。`)
        ),
        h("button", {
          class: "btn small gold",
          onClick: () => {
            sfx.click();
            startFlow(p0.uid);
          }
        }, "现在开荚")
      ));
    } else {
      skipPodOnce = false;
      if (s.pending || growQueue.length) {
        el.append(h(
          "div",
          { class: "gift-card" },
          h(
            "div",
            { class: "gc-text" },
            "花房里",
            h("b", null, s.pending ? "有一株花开好了" : `还有 ${growQueue.length} 株等着照看`),
            h("div", { class: "gc-sub" }, s.pending ? "去采收花材，别让它谢在花房里。" : "剥好的种荚在花房里等着浇水培育。")
          ),
          h("button", {
            class: "btn small gold",
            onClick: () => {
              sfx.click();
              if (s.pending && resumePending()) setState({ screen: "flow" });
              else if (growQueue.length) startFlow(growQueue[0].uid);
              else setState({ screen: "house" });
            }
          }, "回花房照看")
        ));
      }
    }
    const free = boxFreeLeft();
    const cost = boxCost();
    el.append(h(
      "div",
      { class: "box-meta" },
      h("div", null, "完好种子", h("b", null, String((_a = s.seeds.intact) != null ? _a : 0))),
      h("div", null, "破损种子", h("b", null, String((_b = s.seeds.broken) != null ? _b : 0))),
      h("div", null, "下一只", h("b", null, free > 0 ? `免费剩 ${free}` : `${cost} 币`))
    ));
    const ms = nextMilestone(s);
    if (ms) {
      el.append(h(
        "div",
        { class: "box-goal" },
        h("div", { class: "bg-text" }, `再开 ${ms.left} 只`, h("span", null, ms.note)),
        h("div", { class: "bg-bar" }, h("i", { style: `width:${ms.pct}%` }))
      ));
    }
    if (!boxAffordable()) {
      const seedTotal = ((_c = s.seeds.intact) != null ? _c : 0) + ((_d = s.seeds.broken) != null ? _d : 0);
      const stuck = seedTotal === 0 && Object.values((_e = s.crafts) != null ? _e : {}).reduce((a, b) => a + b, 0) === 0 && Object.values((_f = s.petals) != null ? _f : {}).reduce((a, b) => a + b, 0) === 0;
      el.append(h(
        "div",
        { class: "broke-strip" },
        h("div", null, "花铜币不够开下一只了", h("div", { class: "bs-sub" }, seedTotal ? "先拿种子去换点零钱，或去集市卖成品、卖花材。" : "去工坊把花材做成手作，再摆上集市换币。")),
        h(
          "div",
          { class: "bs-acts" },
          seedTotal ? h("button", {
            class: "btn small gold",
            onClick: () => {
              sfx.click();
              setState({ ui: __spreadProps(__spreadValues({}, getState().ui), { casketTab: "trade" }) });
              rerender();
            }
          }, "种子换币") : null,
          h(
            "button",
            {
              class: "btn small",
              onClick: () => {
                sfx.click();
                setState({ screen: "market", ui: __spreadProps(__spreadValues({}, getState().ui), { marketTab: "sell" }) });
              }
            },
            "去集市"
          ),
          // \u771F\u7684\u4E00\u65E0\u6240\u6709\u3001\u53C8\u5F00\u4E0D\u8D77\u4E0B\u4E00\u53EA\u65F6\uFF0C\u7ED9\u4E00\u4E2A\u91CD\u6765\u7684\u51FA\u53E3
          stuck ? h(
            "button",
            {
              class: "btn small ghost",
              onClick: () => {
                sfx.click();
                confirmRestart();
              }
            },
            "破产重来"
          ) : null
        )
      ));
    }
    if (boxGiftReady()) {
      el.append(h(
        "div",
        { class: "gift-card" },
        h("div", { class: "gc-text" }, "今日花娘馈赠", h("div", { class: "gc-sub" }, `还没领：随机道具 ×${boxGiftSize()}（限定陈设每件可多加 1 份）`)),
        h("button", {
          class: "btn small gold",
          onClick: () => {
            const r = takeBoxGift();
            if (!r.ok) return;
            sfx.coin();
            const names = Object.entries(r.got).map(([k, n]) => `${BOX_PROPS[k].name}×${n}`).join("、");
            toast(`收到馈赠：${names}`, "gold");
            rerender();
          }
        }, "领馈赠")
      ));
    }
    const chosen = session2.props;
    el.append(
      h("div", { class: "sec" }, "开匣前勾选道具", h("span", { class: "sec-aside" }, "生效会有画面变化，不勾选就没有"))
    );
    el.append(h(
      "div",
      { class: "prop-pick" },
      PRE_PROPS.map((id) => {
        var _a2;
        const cfg = BOX_PROPS[id];
        const own = (_a2 = s.boxProps[id]) != null ? _a2 : 0;
        const on = chosen.includes(id);
        return h(
          "button",
          {
            class: `prop-chip${on ? " on" : ""}${own <= 0 ? " broke" : ""}`,
            onClick: () => {
              if (own <= 0) {
                toast(`${cfg.name}用完了，去道具铺补一个`, "bad");
                return;
              }
              sfx.click();
              session2.props = on ? chosen.filter((x) => x !== id) : [...chosen, id];
              rerender();
            }
          },
          h("span", { class: "prop-ico", style: propStyle(id) }),
          h("span", { class: "prop-name" }, cfg.name),
          h("span", { class: "prop-own" }, `×${own}`)
        );
      })
    ));
    const face = h("div", { class: "box-face" });
    const fxTorch = h("div", { class: "fx fx-torch" });
    const fxCloth = h("div", { class: "fx fx-cloth" });
    const fxDew = h("div", { class: "fx fx-dew" });
    const fxLens = h("div", { class: "fx fx-lens" });
    const bandTag = h("div", { class: "box-band" }, "闭合");
    const stage = h("div", { class: "box-stage" }, face, fxCloth, fxTorch, fxLens, fxDew, bandTag);
    const needle = h("b", { class: "needle" });
    const safeBar = h("i", { class: "ruler-safe", style: "display:none" });
    const ruler = h(
      "div",
      { class: "ruler" },
      h(
        "div",
        { class: "ruler-track" },
        h("i", { class: "ruler-tight", style: `width:${ANGLE_TOO_TIGHT}%` }),
        safeBar,
        h("i", { class: "ruler-danger", style: `left:${ANGLE_DANGER}%;right:0` }),
        needle
      ),
      h(
        "div",
        { class: "ruler-labels" },
        h("span", { style: `left:${ANGLE_TOO_TIGHT}%` }, "微开"),
        h("span", { style: `left:${ANGLE_BANDS[1].max}%` }, "半开"),
        h("span", { style: `left:${ANGLE_BANDS[2].max}%` }, "大开"),
        h("span", { style: `left:${ANGLE_BANDS[3].max}%` }, "过度")
      )
    );
    const hint = h("div", { class: "flow-hint" }, "在画面上下滑动：向上开大、向下收小。");
    let lastCell = null;
    function paint() {
      const a = session2.angle;
      const band = angleBand(a);
      if (band.cell !== lastCell) {
        lastCell = band.cell;
        if (band.cell < 0) {
          face.style.backgroundImage = `url(${ART.box.closed})`;
          face.style.backgroundSize = "cover";
          face.style.backgroundPosition = "center";
        } else {
          const st = spriteStyle(ART.box.states.url, ART.box.states.rows, ART.box.states.cols, band.cell);
          face.style.backgroundImage = st["background-image"];
          face.style.backgroundSize = st["background-size"];
          face.style.backgroundPosition = st["background-position"];
        }
      }
      needle.style.left = `${a}%`;
      bandTag.textContent = a < ANGLE_TOO_TIGHT ? "还太紧" : `${band.label} · ${Math.round(a)}°`;
      stage.classList.toggle("danger", a >= ANGLE_DANGER);
      const zone = safeZone(session2.props);
      fxTorch.style.setProperty("--seed-x", `${zone.center}%`);
      if (hasProp("lens")) {
        safeBar.style.display = "";
        safeBar.style.left = `${zone.lo}%`;
        safeBar.style.width = `${Math.max(2, zone.hi - zone.lo)}%`;
      } else {
        safeBar.style.display = "none";
      }
      fxCloth.classList.toggle("on", hasProp("cloth"));
      fxDew.classList.toggle("on", hasProp("dew"));
      fxTorch.classList.toggle("on", hasProp("torch"));
      fxLens.classList.toggle("on", hasProp("lens"));
      const outcome = angleOutcome(a, session2.props);
      takeBtn.disabled = session2.phase !== "aim" || outcome === "tight";
      hint.textContent = session2.phase !== "aim" ? "这一只已经开完了，结果在下面。" : outcome === "tight" ? a < ANGLE_TOO_TIGHT ? "匣壳只松开一条缝，种子还卡在匣心——再往上开大一点。" : "开到「微开」还夹不出种子，再往上开到「半开」。" : outcome === "intact" ? "停在「半开」最稳，按「取出种子」就是完好种子——这一按会消耗这只花匣。" : outcome === "broken" ? "开到「大开」会刮伤种子，只能取出破损种子，收回一点更划算。" : "开过头了！匣壳正在向内挤压种子，收回一点再取。";
    }
    let startY = 0;
    let startAngle = 0;
    let lastAngle = 0;
    stage.addEventListener("pointerdown", (e) => {
      if (session2.phase !== "aim") return;
      stage.setPointerCapture(e.pointerId);
      startY = e.clientY;
      startAngle = session2.angle;
      lastAngle = session2.angle;
      stage.classList.add("grabbing");
    });
    stage.addEventListener("pointermove", (e) => {
      var _a2;
      if (session2.phase !== "aim" || !((_a2 = stage.hasPointerCapture) == null ? void 0 : _a2.call(stage, e.pointerId))) return;
      const want = Math.max(0, Math.min(100, startAngle + (startY - e.clientY) * 0.55));
      if (hasProp("dew")) {
        session2.angle = want;
      } else {
        const step = want - lastAngle;
        const slip = Math.abs(step) > 1.2 ? Math.min(5, Math.abs(step) * 0.45) * (step > 0 ? 1 : -0.4) : 0;
        session2.angle = Math.max(0, Math.min(100, want + slip));
        lastAngle = session2.angle;
      }
      paint();
    });
    const endDrag = (e) => {
      var _a2, _b2;
      if (!((_a2 = stage.hasPointerCapture) == null ? void 0 : _a2.call(stage, e.pointerId))) return;
      stage.classList.remove("grabbing");
      (_b2 = stage.releasePointerCapture) == null ? void 0 : _b2.call(stage, e.pointerId);
    };
    stage.addEventListener("pointerup", endDrag);
    stage.addEventListener("pointercancel", endDrag);
    const takeBtn = h("button", {
      class: "btn gold big",
      onClick: () => {
        if (!boxAffordable()) {
          toast("花铜币不够买下一只花匣了", "bad");
          return;
        }
        const r = settleCasket(session2.angle, session2.props);
        if (r.result === "poor") {
          toast("花铜币不够买下一只花匣了", "bad");
          return;
        }
        if (r.result === "tight") {
          sfx.click();
          toast("卡住了，种子取不出来——这次不消耗", "info");
          paint();
          return;
        }
        session2.result = r.result;
        session2.used = r.used;
        session2.cost = r.cost;
        session2.phase = "result";
        if (r.result === "intact") sfx.bloom();
        else if (r.result === "broken") sfx.seed();
        else sfx.dead();
        const notes = checkBoxMilestones();
        rerender();
        notes.forEach((n, i) => setTimeout(() => toast(n, "gold"), 700 + i * 1400));
      }
    }, "取出种子");
    stage.append(h("div", { class: "box-grab" }, "↕"));
    el.append(h("div", { class: "box-wrap" }, stage, ruler, hint, h("div", { style: "margin-top:10px" }, takeBtn)));
    paint();
    if (session2.phase === "result") renderResult(el, rerender);
  }
  function renderPodOpen(el, rerender) {
    const s = getState();
    if (!session2 || session2.phase !== "aim") session2 = newSession();
    const pod = s.pods.find((p) => p.uid === podOpening);
    const pc = pod ? podById(pod.type) : null;
    el.append(h(
      "div",
      { class: "scene-card" },
      img(pc ? ART.pods[pod.type] : ART.box.closed, "", pc ? pc.name : "种荚"),
      h("div", { class: "sc-veil" }),
      h("div", { class: "sc-label" }, "花匣 · 开荚"),
      h("div", { class: "sc-sub" }, pc ? "用开匣的手法剥开这枚种荚" : "用开匣的手法剥开这枚种荚")
    ));
    el.append(h(
      "div",
      { class: "gift-card" },
      h(
        "div",
        { class: "gc-text" },
        "正在开：",
        h("b", null, pc ? pc.name : "种荚"),
        h("div", { class: "gc-sub" }, "和开匣同一套判定：停在「半开」取出完好种球，「大开」会刮伤种球（开出的花降一档），开到「过度」会夹碎种球。")
      ),
      h(
        "div",
        { style: "display:flex;gap:8px;flex-shrink:0" },
        h("button", { class: "btn small ghost", onClick: () => {
          sfx.click();
          cancelPodOpen();
        } }, "先不开"),
        h("button", { class: "btn small", onClick: () => {
          sfx.click();
          skipPodOnce = true;
          podOpening = null;
          session2 = newSession();
          rerender();
        } }, "先开匣取种子")
      )
    ));
    const face = h("div", { class: "box-face" });
    const bandTag = h("div", { class: "box-band" }, "闭合");
    const stage = h("div", { class: "box-stage" }, face, bandTag);
    const needle = h("b", { class: "needle" });
    const safeBar = h("i", { class: "ruler-safe" });
    const ruler = h(
      "div",
      { class: "ruler" },
      h(
        "div",
        { class: "ruler-track" },
        h("i", { class: "ruler-tight", style: `width:${ANGLE_TOO_TIGHT}%` }),
        safeBar,
        h("i", { class: "ruler-danger", style: `left:${ANGLE_DANGER}%;right:0` }),
        needle
      ),
      h(
        "div",
        { class: "ruler-labels" },
        h("span", { style: `left:${ANGLE_TOO_TIGHT}%` }, "微开"),
        h("span", { style: `left:${ANGLE_BANDS[1].max}%` }, "半开"),
        h("span", { style: `left:${ANGLE_BANDS[2].max}%` }, "大开"),
        h("span", { style: `left:${ANGLE_BANDS[3].max}%` }, "过度")
      )
    );
    const hint = h("div", { class: "flow-hint" }, "在画面上下滑动：向上开大、向下收小。");
    function paint() {
      const a = session2.angle;
      const band = angleBand(a);
      if (band.cell < 0) {
        face.style.backgroundImage = `url(${ART.box.closed})`;
        face.style.backgroundSize = "cover";
        face.style.backgroundPosition = "center";
      } else {
        const st = spriteStyle(ART.box.states.url, ART.box.states.rows, ART.box.states.cols, band.cell);
        face.style.backgroundImage = st["background-image"];
        face.style.backgroundSize = st["background-size"];
        face.style.backgroundPosition = st["background-position"];
      }
      needle.style.left = `${a}%`;
      bandTag.textContent = a < ANGLE_TOO_TIGHT ? "还太紧" : band.label + " · " + Math.round(a) + "°";
      stage.classList.toggle("danger", a >= ANGLE_DANGER);
      const zone = safeZone([]);
      safeBar.style.left = `${zone.lo}%`;
      safeBar.style.width = `${Math.max(2, zone.hi - zone.lo)}%`;
      const outcome = angleOutcome(a, []);
      takeBtn.disabled = outcome === "tight";
      hint.textContent = outcome === "tight" ? a < ANGLE_TOO_TIGHT ? "荚壳只松开一条缝，种球还卡在里面，再往大开一点。" : "开到「微开」还夹不出种球，再往上开到「半开」。" : outcome === "intact" ? "停在「半开」最稳，按「取出种球」可以完整取出。" : outcome === "broken" ? "开到「大开」会刮伤种球，开出的花会降一档品质，收回一点更划算。" : "开过头了！这样会把种球夹碎，收回一点再取。";
    }
    let startY = 0;
    let startAngle = 0;
    let lastAngle = 0;
    stage.addEventListener("pointerdown", (e) => {
      stage.setPointerCapture(e.pointerId);
      startY = e.clientY;
      startAngle = session2.angle;
      lastAngle = session2.angle;
      stage.classList.add("grabbing");
    });
    stage.addEventListener("pointermove", (e) => {
      var _a;
      if (!((_a = stage.hasPointerCapture) == null ? void 0 : _a.call(stage, e.pointerId))) return;
      const want = Math.max(0, Math.min(100, startAngle + (startY - e.clientY) * 0.55));
      const step = want - lastAngle;
      const slip = Math.abs(step) > 1.2 ? Math.min(5, Math.abs(step) * 0.45) * (step > 0 ? 1 : -0.4) : 0;
      session2.angle = Math.max(0, Math.min(100, want + slip));
      lastAngle = session2.angle;
      paint();
    });
    const endDrag = (e) => {
      var _a, _b;
      if (!((_a = stage.hasPointerCapture) == null ? void 0 : _a.call(stage, e.pointerId))) return;
      stage.classList.remove("grabbing");
      (_b = stage.releasePointerCapture) == null ? void 0 : _b.call(stage, e.pointerId);
    };
    stage.addEventListener("pointerup", endDrag);
    stage.addEventListener("pointercancel", endDrag);
    const takeBtn = h("button", {
      class: "btn gold big",
      onClick: () => {
        if (!podOpening) return;
        const a = session2.angle;
        const outcome = angleOutcome(a, []);
        if (outcome === "tight") {
          sfx.click();
          toast("卡住了，种球取不出来——这次不消耗，再开大一点", "info");
          paint();
          return;
        }
        if (outcome === "ruined") {
          sfx.dead();
          toast("开过头了，荚壳夹碎了种球", "bad");
          finishPodOpen("ruined");
          return;
        }
        sfx.seed();
        if (outcome === "broken") {
          toast("种球被荚壳刮伤了，开出的花会降一档", "bad");
          finishPodOpen("broken");
          return;
        }
        toast("种球完好地取出来了", "gold");
        finishPodOpen("intact");
      }
    }, "取出种球");
    stage.append(h("div", { class: "box-grab" }, "↕"));
    el.append(h("div", { class: "box-wrap" }, stage, ruler, hint, h("div", { style: "margin-top:10px" }, takeBtn)));
    paint();
    void rerender;
  }
  function renderResult(el, rerender) {
    var _a, _b;
    const s = getState();
    const key = session2.result;
    const info = SEED_RESULTS[key];
    const canPaste = key === "broken" && ((_a = s.boxProps.paste) != null ? _a : 0) > 0 && ((_b = s.seeds.broken) != null ? _b : 0) > 0;
    const peelQ = s.pods.filter((p) => !p.peeled);
    const peelLeft = peelQ.length ? { uid: peelQ[0].uid, n: peelQ.length } : null;
    const goal = decorGoal(s);
    const cell = session2.repaired ? 3 : { intact: 0, broken: 1, ruined: 2 }[key];
    const art = cell === void 0 ? h("div", { class: "result-art", style: cssOf(spriteStyle(ART.box.closed, 1, 1, 0)) }) : h("div", { class: "result-art", style: cssOf(spriteStyle(ART.seeds.url, ART.seeds.rows, ART.seeds.cols, cell)) });
    el.append(h(
      "div",
      { class: `result-card tone-${info.tone}` },
      art,
      h("div", { class: "r-title" }, info.title),
      h("div", { class: "r-line" }, info.line),
      key !== "ruined" ? h("div", { class: "r-sub" }, `本次开合角度 ${Math.round(session2.angle)}° · 消耗 ${session2.cost === 0 ? "免费额度" : `${session2.cost} 币`}`) : h("div", { class: "r-sub" }, `开合角度 ${Math.round(session2.angle)}° · 这一只白开了`),
      session2.used.length ? h("div", { class: "r-used" }, "生效道具：", session2.used.map((u) => BOX_PROPS[u].name).join("、")) : null,
      // 每次开出的种子都要有归属：直接指出下一件限定陈设还差什么、进度多少
      goal ? h(
        "div",
        { class: "r-next" },
        h(
          "div",
          { class: "rn-head" },
          "下一件目标",
          h("b", null, goal.name),
          goal.lack ? h("span", { class: "rn-lack" }, `还差 ${goal.lack}`) : h("span", { class: "rn-ready" }, "材料够了，去摆进花房")
        ),
        h("div", { class: "rn-bar" }, h("i", { style: `width:${goal.pct}%` }))
      ) : null,
      h(
        "div",
        { class: "r-actions" },
        // \u53D6\u51FA\u79CD\u5B50\u540E\u5FC5\u987B\u80FD\u987A\u7740\u82B1\u623F\u6D41\u7A0B\u8D70\u4E0B\u53BB\uFF1A\u79CD\u4E0B\u5C31\u53BB\u7B2C\u4E8C\u6B65\uFF08\u6D47\u6C34\u57F9\u80B2\uFF09
        key === "intact" || key === "broken" ? h("button", {
          class: "btn small gold",
          onClick: () => {
            sfx.click();
            sowAndStart(key);
          }
        }, key === "intact" ? "种进花房 · 去浇水培育" : "把破损种子种下 · 去浇水") : null,
        peelLeft ? h("button", {
          class: "btn small ghost",
          onClick: () => {
            sfx.click();
            startFlow(peelLeft.uid);
          }
        }, `去开荚（背包里还有 ${peelLeft.n} 枚没剥壳）`) : null,
        canPaste ? h("button", {
          class: "btn small ghost",
          onClick: () => {
            const r = usePaste();
            if (!r.ok) {
              toast("没有可修复的破损种子", "bad");
              return;
            }
            sfx.craft();
            session2.result = "intact";
            session2.repaired = true;
            toast("玉膏抹过，裂口合上了——破损种子修复为完好", "gold");
            rerender();
          }
        }, `用修复玉膏救回来（剩 ${s.boxProps.paste}）`) : null,
        key === "ruined" ? h("span", { class: "r-hint" }, "彻底损毁的种子无法修复") : null,
        h("button", {
          class: "btn",
          onClick: () => {
            if (!boxAffordable()) {
              toast("花铜币不够买下一只花匣了", "bad");
              return;
            }
            sfx.click();
            session2 = newSession();
            rerender();
          }
        }, `再开一只（${boxFreeLeft() > 0 ? "免费" : `${BOX_PRICE} 币`}）`),
        h("button", {
          class: "btn small ghost",
          onClick: () => {
            sfx.click();
            toTrade();
            rerender();
          }
        }, goal ? `看${goal.name}还差什么` : "看种子能换什么")
      )
    ));
  }
  function renderTrade(el, rerender) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
    const s = getState();
    el.append(h(
      "div",
      { class: "guide-banner" },
      h("b", null, "完好种子"),
      "能换限定陈设与稀荚配额；",
      h("b", null, "破损种子"),
      "换零钱和普通耗材。"
    ));
    const seedTotal2 = ((_b = (_a = s.seeds) == null ? void 0 : _a.intact) != null ? _b : 0) + ((_d = (_c = s.seeds) == null ? void 0 : _c.broken) != null ? _d : 0);
    if (seedTotal2) {
      el.append(h(
        "div",
        { class: "row-card" },
        h(
          "div",
          { class: "rc-main" },
          h("div", { class: "rc-name" }, "种进花房", h("span", { class: "chip" }, `完好 ${(_e = s.seeds.intact) != null ? _e : 0} · 破损 ${(_f = s.seeds.broken) != null ? _f : 0}`)),
          h("div", { class: "rc-sub" }, "种子也能下土：种下直接进入第二步（浇水培育），破损种子会降一档品质。")
        ),
        h(
          "div",
          { class: "rc-side" },
          h("button", {
            class: "btn small gold",
            onClick: () => {
              var _a2, _b2;
              sfx.click();
              sowAndStart(((_b2 = (_a2 = s.seeds) == null ? void 0 : _a2.intact) != null ? _b2 : 0) > 0 ? "intact" : "broken");
            }
          }, "种一颗")
        )
      ));
    }
    for (const r of SEED_EXCHANGES) {
      const ok = seedExchangeCan(r.id);
      const need = [r.need.intact ? `完好×${r.need.intact}` : null, r.need.broken ? `破损×${r.need.broken}` : null].filter(Boolean).join(" + ");
      el.append(h(
        "div",
        { class: "row-card" },
        h(
          "div",
          { class: "rc-main" },
          h("div", { class: "rc-name" }, r.name, h("span", { class: "chip" }, need)),
          h("div", { class: "rc-sub" }, r.note)
        ),
        h(
          "div",
          { class: "rc-side" },
          h("button", {
            class: `btn small${ok ? "" : " disabled"}`,
            onClick: () => {
              const res = seedExchange(r.id);
              if (!res.ok) {
                toast("种子不够", "bad");
                return;
              }
              sfx.coin();
              toast(`兑换成功：${gainText(res.gain)}`, "gold");
              rerender();
            }
          }, "兑换")
        )
      ));
    }
    el.append(h("div", { class: "sec" }, "限定陈设", h("span", { class: "sec-aside" }, `已摆进花房 ${boxDecorCount()}/3`)));
    for (const [id, d] of Object.entries(BOX_DECOR)) {
      const owned = !!((_g = s.boxDecor) == null ? void 0 : _g[id]);
      const ok = decorCan(id);
      const need = [d.need.intact ? `完好×${d.need.intact}` : null, d.need.broken ? `破损×${d.need.broken}` : null].filter(Boolean).join(" + ");
      el.append(h(
        "div",
        { class: `row-card decor${owned ? " owned" : ""}` },
        h(
          "div",
          { class: "rc-main" },
          h("div", { class: "rc-name" }, d.name, owned ? h("span", { class: "chip on" }, "已获得") : h("span", { class: "chip" }, need)),
          h("div", { class: "rc-sub" }, d.note)
        ),
        h(
          "div",
          { class: "rc-side" },
          owned ? null : h("button", {
            class: `btn small gold${ok ? "" : " disabled"}`,
            onClick: () => {
              const res = buyDecor(id);
              if (!res.ok) {
                toast("种子还不够", "bad");
                return;
              }
              sfx.bloom();
              toast(`${d.name}已摆进花房，每日馈赠 +1`, "gold");
              rerender();
            }
          }, "摆进花房")
        )
      ));
    }
    const opened = (_i = (_h = s.boxStats) == null ? void 0 : _h.opened) != null ? _i : 0;
    el.append(h("div", { class: "sec" }, "开匣记录", h("span", { class: "sec-aside" }, `累计 ${opened} 只`)));
    el.append(h(
      "div",
      { class: "box-tally" },
      h("div", null, "完好", h("b", null, String((_j = s.boxStats.intact) != null ? _j : 0))),
      h("div", null, "破损", h("b", null, String((_k = s.boxStats.broken) != null ? _k : 0))),
      h("div", null, "损毁", h("b", null, String((_l = s.boxStats.ruined) != null ? _l : 0)))
    ));
    for (const m of BOX_MILESTONES) {
      const done = !!((_m = s.boxStats.milestones) == null ? void 0 : _m[m.at]);
      el.append(h(
        "div",
        { class: "mile" },
        h("span", { class: `mile-dot${done ? " on" : ""}` }),
        h(
          "div",
          null,
          `${m.at} 只：${Object.entries(m.props).map(([k, v]) => `${BOX_PROPS[k].name}×${v}`).join("、")}`,
          done ? null : h("div", { class: "mile-sub" }, `还差 ${Math.max(0, m.at - opened)} 只`)
        )
      ));
    }
  }
  function gainText(g) {
    var _a, _b;
    const bits = [];
    if (g.coin) bits.push(`花铜币 +${g.coin}`);
    if (g.goldenQuota) bits.push("今日花市必上黄金灵荚");
    for (const [k, v] of Object.entries((_a = g.consumables) != null ? _a : {})) bits.push(`${(_b = BOX_CONSUM_NAME[k]) != null ? _b : k} +${v}`);
    return bits.join("，");
  }
  var BOX_CONSUM_NAME = { card: "卡纸", frame: "相框", resin: "滴胶", ribbon: "丝带" };
  function renderShop2(el, rerender) {
    var _a;
    const s = getState();
    el.append(h(
      "div",
      { class: "guide-banner" },
      "道具只提供辅助：手电看得清、镜片有标线、绒布抗损毁、香露防滑脱、玉膏能救一次——",
      h("b", null, "都不能保证必出完好种子"),
      "。"
    ));
    for (const [id, cfg] of Object.entries(BOX_PROPS)) {
      const afford = s.coin >= cfg.price;
      el.append(h(
        "div",
        { class: "row-card" },
        h("span", { class: "prop-ico big", style: cssOf(propStyle(id)) }),
        h(
          "div",
          { class: "rc-main" },
          h("div", { class: "rc-name" }, cfg.name, h("span", { class: "chip" }, `已有 ×${(_a = s.boxProps[id]) != null ? _a : 0}`)),
          h("div", { class: "rc-sub" }, cfg.desc),
          h("div", { class: "rc-sub fx-line" }, "生效表现：", cfg.effect, cfg.stage === "post" ? "（开匣后在结果里用）" : "")
        ),
        h(
          "div",
          { class: "rc-side" },
          h("div", { class: "coin-inline" }, h("span", { class: "coin-ico" }, "花"), String(cfg.price)),
          h("button", {
            class: `btn small${afford ? "" : " disabled"}`,
            style: "margin-top:6px",
            onClick: () => {
              const r = buyBoxProp(id);
              if (!r.ok) {
                toast("花铜币不够啦", "bad");
                return;
              }
              sfx.coin();
              toast(`购入 ${cfg.name}`, "gold");
              rerender();
            }
          }, "买一个")
        )
      ));
    }
  }
  var screens_default = {
    house: renderHouse,
    market: renderMarket,
    workshop: renderWorkshop,
    album: renderAlbum,
    flow: renderFlow,
    casket: renderCasket
  };
  var prevCoin = null;
  var prevScreen = null;
  var rendering = false;
  function render() {
    if (rendering) return;
    rendering = true;
    try {
      renderNow();
    } finally {
      rendering = false;
    }
  }
  function renderNow() {
    var _a;
    const s = getState();
    if (s.screen === "flow" && isSettling()) return;
    const coinChanged = prevCoin !== null && prevCoin !== s.coin;
    prevCoin = s.coin;
    renderTopbar(document.getElementById("topbar"), coinChanged);
    renderNav(document.getElementById("navbar"));
    const screenEl = document.getElementById("screen");
    screenEl.replaceChildren();
    let id = s.screen;
    if (s.pending && !hasSession() && (s.screen === "flow" || s.screen === "house")) {
      resumePending();
      id = "flow";
      if (s.screen !== "flow") setState({ screen: "flow" });
    } else if (id === "flow" && !hasSession()) {
      id = "house";
      Promise.resolve().then(() => setState({ screen: "house" }));
    }
    ;
    ((_a = screens_default[id]) != null ? _a : screens_default.house)(screenEl, render);
    if (prevScreen !== id) {
      prevScreen = id;
      screenEl.scrollTop = 0;
      warmForScreen();
    }
  }
  function showTutorial() {
    showModal({
      title: "欢迎来到种荚花坊",
      dismissable: false,
      body: h(
        "div",
        { style: "font-size:13px;line-height:2;color:var(--ink)" },
        h("div", null, "一、去", h("b", null, "花市"), "挑一枚种荚——价格和外壳线索都写在卡片上。"),
        h("div", null, "二、", h("b", null, "剥壳、浇水、等花开"), "：普通、稀有，还有罕见的变异。"),
        h("div", null, "三、采收花材去", h("b", null, "工坊"), "做押花和滴胶，摆上集市换花铜币。"),
        h("div", { style: "color:var(--ink-2);font-size:12px;margin-top:6px" }, "外壳会骗人，但花不会。祝第一枚就开出稀有的。")
      ),
      actions: [{ label: "开始经营", onClick: () => finishTutorial() }]
    });
  }
  async function main() {
    var _a;
    let sdk = null;
    try {
      if (window.GameSDK) {
        sdk = await window.GameSDK.init();
        console.log("[game] ready, gameId =", (_a = sdk == null ? void 0 : sdk.context) == null ? void 0 : _a.gameId);
      } else {
        console.warn("[game] GameSDK 不存在，使用内存存档模式");
      }
    } catch (e) {
      console.warn("[game] SDK init failed, running in local fallback", e);
    }
    bindModalRoot(document.getElementById("modal-root"));
    const saver2 = createSaver(sdk, getState);
    setSaver(saver2);
    const raw = await load(sdk);
    if (raw) replaceAll(mergeSave(raw));
    newDayCheck();
    warmCritical();
    if (resumePending()) setState({ screen: "flow" });
    subscribe(render);
    render();
    if (!getState().tutorialDone && getState().stats.opened === 0) showTutorial();
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") saver2.flush();
    });
  }
  main().catch((e) => {
    console.error("[game] 启动异常", e);
    const el = document.getElementById("screen");
    if (el) {
      el.replaceChildren(h(
        "div",
        { class: "card", style: "margin-top:24px" },
        h("div", { class: "sec" }, "花坊暂时打烊了"),
        h(
          "div",
          { style: "font-size:13px;line-height:1.8;color:var(--ink-2)" },
          "加载时遇到一点问题，刷新一下页面就能重新开张。若反复出现，请把这条信息发给作者：",
          h("br"),
          h("code", { style: "font-size:11px;opacity:.8" }, String(e && e.message || e))
        )
      ));
    }
  });
})();
